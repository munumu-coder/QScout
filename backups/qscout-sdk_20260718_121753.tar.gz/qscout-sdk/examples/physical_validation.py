#!/usr/bin/env python3
"""Physical validation of QScout SDK against real robot.

Run:
    cd /home/munumu/qscout-sdk
    PYTHONPATH=src python3 examples/physical_validation.py
"""

import struct
import sys
import time

sys.path.insert(0, "src")

from qscout import QScoutConnection, build_packet, receive_packet
from qscout import sensors


def log(msg: str) -> None:
    print(f"  {msg}")


def hex_bytes(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


def section(title: str) -> None:
    print()
    print(f"{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


def drain_pending(conn: QScoutConnection) -> None:
    """Discard any stale bytes in the RX buffer."""
    conn._serial.reset_input_buffer()
    time.sleep(0.05)


def send_and_try_ack(conn: QScoutConnection, oid: int, action: int, payload: bytes = b"") -> bytes:
    """Send a command and attempt to read an ACK (with short timeout)."""
    raw = build_packet(oid, action, payload)
    conn.send(raw)
    time.sleep(0.15)
    if conn._serial.in_waiting >= 6:
        try:
            conn._serial.timeout = 0.3
            oid_rx, action_rx, _ = receive_packet(conn)
            conn._serial.timeout = 2.0
            return raw
        except Exception:
            conn._serial.timeout = 2.0
    return raw


_order_id = 2
def next_oid() -> int:
    global _order_id
    oid = _order_id
    _order_id += 1
    if _order_id > 254:
        _order_id = 2
    return oid


def main() -> None:
    print("=" * 60)
    print("  QScout Physical Validation — SDK-02 Fase 2B")
    print("=" * 60)

    try:
        with QScoutConnection("/dev/ttyUSB0", 115200, timeout=2.0) as conn:
            drain_pending(conn)
            log("Connected to /dev/ttyUSB0 — RX buffer flushed")
            results = {}

            # ---- TEST 1: LED ----
            section("TEST 1 — LED")
            try:
                oid = next_oid()
                raw = build_packet(oid, 0x10, bytes([0xFC, 0xFF, 0x00, 0x00]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                time.sleep(2.0)
                log("  >> LED should be RED")
                log("  >> Press Enter to turn off...")
                input()
                oid = next_oid()
                raw = build_packet(oid, 0x10, bytes([0xFC, 0x00, 0x00, 0x00]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                log("  >> LED should be OFF")
                answer = input("  >> Was LED red then off? (y/n) ").strip().lower()
                results["LED"] = answer == "y"
            except Exception as e:
                log(f"  FAIL: {e}")
                results["LED"] = False

            # ---- TEST 2: BUZZER ----
            section("TEST 2 — BUZZER")
            try:
                drain_pending(conn)
                oid = next_oid()
                payload = struct.pack("<BHH", 0, 440, 500)
                raw = build_packet(oid, 0x13, payload)
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                time.sleep(0.5)
                if conn._serial.in_waiting >= 6:
                    rx_oid, rx_action, rx_payload = receive_packet(conn)
                    log(f"RX: oid={rx_oid}, action=0x{rx_action:02X}")
                else:
                    log("  (no ACK received)")
                time.sleep(0.5)
                answer = input("  >> Did you hear a 440Hz tone? (y/n) ").strip().lower()
                results["BUZZER"] = answer == "y"
            except Exception as e:
                log(f"  FAIL: {e}")
                results["BUZZER"] = False

            # ---- TEST 3: MOTOR ----
            section("TEST 3 — MOTOR")
            try:
                drain_pending(conn)
                oid = next_oid()
                raw = build_packet(oid, 0x11, bytes([0xFF, 0x32]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                time.sleep(2.0)
                log("  >> Motor M1 should spin")
                log("  >> Press Enter to stop...")
                input()
                oid = next_oid()
                raw = build_packet(oid, 0x11, bytes([0xFF, 0x00]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                answer = input("  >> Did motor spin then stop? (y/n) ").strip().lower()
                results["MOTOR"] = answer == "y"
            except Exception as e:
                log(f"  FAIL: {e}")
                results["MOTOR"] = False

            # ---- TEST 4: MOVE ----
            section("TEST 4 — MOVE")
            try:
                drain_pending(conn)
                oid = next_oid()
                raw = build_packet(oid, 0x11, bytes([0x00, 0x32, 0x32]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                time.sleep(2.0)
                log("  >> Robot should move forward")
                log("  >> Press Enter to stop...")
                input()
                oid = next_oid()
                raw = build_packet(oid, 0x11, bytes([0x00, 0x00, 0x00]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                answer = input("  >> Did robot move then stop? (y/n) ").strip().lower()
                results["MOVE"] = answer == "y"
            except Exception as e:
                log(f"  FAIL: {e}")
                results["MOVE"] = False

            # ---- TEST 5: ULTRASONIC ----
            section("TEST 5 — ULTRASONIC")
            try:
                drain_pending(conn)
                time.sleep(0.3)
                drain_pending(conn)
                oid = next_oid()
                raw = build_packet(oid, 0xA1, bytes([0x01]))
                log(f"TX: {hex_bytes(raw)}")
                conn.send(raw)
                time.sleep(1.0)
                rx_oid, rx_action, rx_payload = receive_packet(conn)
                log(f"RX: oid={rx_oid}, action=0x{rx_action:02X}, payload={hex_bytes(rx_payload)}")
                if len(rx_payload) >= 2:
                    distance = rx_payload[0] * 256 + rx_payload[1]
                    log(f"  Distance: {distance} mm")
                else:
                    distance = 0
                    log(f"  WARNING: payload too short ({len(rx_payload)} bytes)")
                answer = input("  >> Is the distance value reasonable? (y/n) ").strip().lower()
                results["ULTRASONIC"] = answer == "y"
            except Exception as e:
                log(f"  FAIL: {e}")
                results["ULTRASONIC"] = False

            # ---- SUMMARY ----
            section("RESULTS SUMMARY")
            for name, passed in results.items():
                status = "PASS" if passed else "FAIL"
                log(f"  {name:12s}: {status}")
            total_pass = sum(1 for v in results.values() if v)
            total = len(results)
            log(f"\n  Total: {total_pass}/{total} PASS")
            if total_pass == total:
                log("  SDK-02 Fase 2B: VALIDATED")
            else:
                log("  SDK-02 Fase 2B: INCOMPLETE — review failures above")
            print()

    except Exception as e:
        log(f"Connection failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
