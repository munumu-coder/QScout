"""Basic QScout SDK usage examples."""
