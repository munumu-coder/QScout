"""Basic example: connect and send a test packet."""

from qscout import QScoutConnection, RBPacket

PORT = "/dev/ttyUSB0"


def main():
    with QScoutConnection(PORT) as conn:
        pkt = RBPacket(order_id=1, action=0x05)
        print(f"Sending: {pkt!r}")
        conn.send(pkt.to_bytes())

        raw = conn.receive(size=10)
        if raw:
            resp = RBPacket.from_bytes(raw)
            print(f"Received: {resp!r}")
        else:
            print("No response (timeout)")


if __name__ == "__main__":
    main()
