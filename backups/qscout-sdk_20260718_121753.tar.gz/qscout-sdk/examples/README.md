# QScout SDK — Examples

Ejemplos de uso del SDK.

- `test_basic.py`: conexión y envío de paquete de prueba.
