"""Tests for command_map: command definitions and lookup."""

import unittest

from qscout.command_map import (
    CommandDef,
    CommandType,
    GET_DEVICE_INFO,
    GET_INTERFACE_INFO,
    GET_MOTOR_INTERFACE_INFO,
    GET_ULTRASONIC,
    GET_LINE_VALUE,
    SET_LED,
    SET_MOTOR,
    SET_MOVE,
    SET_BUZZER,
    get_command,
    get_commands_by_action,
    list_commands,
)


class TestCommandDef(unittest.TestCase):

    def test_get_device_info_fields(self):
        self.assertEqual(GET_DEVICE_INFO.name, "GET_DEVICE_INFO")
        self.assertEqual(GET_DEVICE_INFO.action, 0x01)
        self.assertIs(GET_DEVICE_INFO.cmd_type, CommandType.GET)
        self.assertTrue(GET_DEVICE_INFO.validated)

    def test_set_led_fields(self):
        self.assertEqual(SET_LED.name, "SET_LED")
        self.assertEqual(SET_LED.action, 0x10)
        self.assertIs(SET_LED.cmd_type, CommandType.SET)
        self.assertTrue(SET_LED.validated)

    def test_pending_command(self):
        from qscout.command_map import GET_FLAME
        self.assertFalse(GET_FLAME.validated)

    def test_repr(self):
        r = repr(GET_DEVICE_INFO)
        self.assertIn("GET_DEVICE_INFO", r)
        self.assertIn("0x01", r)
        self.assertIn("CONFIRMED", r)

    def test_repr_pending(self):
        from qscout.command_map import GET_FLAME
        r = repr(GET_FLAME)
        self.assertIn("PENDING", r)

    def test_equality_same_name_action_type(self):
        a = CommandDef("FOO", 0x01, CommandType.GET)
        b = CommandDef("FOO", 0x01, CommandType.GET)
        self.assertEqual(a, b)

    def test_inequality_different_name(self):
        a = CommandDef("A", 0x01, CommandType.GET)
        b = CommandDef("B", 0x01, CommandType.GET)
        self.assertNotEqual(a, b)

    def test_inequality_different_type(self):
        a = CommandDef("A", 0x11, CommandType.SET)
        b = CommandDef("A", 0x11, CommandType.GET)
        self.assertNotEqual(a, b)


class TestCommandType(unittest.TestCase):

    def test_get_value(self):
        self.assertEqual(CommandType.GET.value, "GET")

    def test_set_value(self):
        self.assertEqual(CommandType.SET.value, "SET")


class TestLookup(unittest.TestCase):

    def test_get_command_valid(self):
        cmd = get_command("SET_LED")
        self.assertEqual(cmd.action, 0x10)

    def test_get_command_unknown(self):
        with self.assertRaises(KeyError):
            get_command("DO_SOMETHING_WILD")

    def test_get_commands_by_action_single(self):
        cmds = get_commands_by_action(0x01)
        self.assertEqual(len(cmds), 1)
        self.assertEqual(cmds[0].name, "GET_DEVICE_INFO")

    def test_get_commands_by_action_shared(self):
        cmds = get_commands_by_action(0x11)
        self.assertEqual(len(cmds), 2)
        names = {c.name for c in cmds}
        self.assertIn("SET_MOTOR", names)
        self.assertIn("SET_MOVE", names)

    def test_get_commands_by_action_unknown(self):
        cmds = get_commands_by_action(0xFF)
        self.assertEqual(cmds, [])

    def test_list_commands_sorted(self):
        cmds = list_commands()
        self.assertGreater(len(cmds), 0)
        actions = [c.action for c in cmds]
        self.assertEqual(actions, sorted(actions))


class TestCommandCounts(unittest.TestCase):

    def test_total_command_definitions(self):
        cmds = list_commands()
        self.assertEqual(len(cmds), 42)

    def test_all_GET_are_GET_type(self):
        cmds = [c for c in list_commands() if c.cmd_type is CommandType.GET]
        self.assertGreater(len(cmds), 0)
        for c in cmds:
            self.assertIs(c.cmd_type, CommandType.GET)

    def test_all_SET_are_SET_type(self):
        cmds = [c for c in list_commands() if c.cmd_type is CommandType.SET]
        self.assertGreater(len(cmds), 0)
        for c in cmds:
            self.assertIs(c.cmd_type, CommandType.SET)

    def test_validated_commands_are_known(self):
        validated = [c for c in list_commands() if c.validated]
        known = {GET_DEVICE_INFO, GET_INTERFACE_INFO, GET_MOTOR_INTERFACE_INFO,
                 GET_ULTRASONIC, GET_LINE_VALUE,
                 SET_LED, SET_MOTOR, SET_MOVE, SET_BUZZER}
        self.assertEqual(set(validated), known)


class TestSharedActionCode(unittest.TestCase):

    def test_0x11_has_two_commands(self):
        cmds = get_commands_by_action(0x11)
        self.assertEqual(len(cmds), 2)

    def test_motor_and_move_are_different(self):
        self.assertNotEqual(SET_MOTOR, SET_MOVE)


if __name__ == "__main__":
    unittest.main()
