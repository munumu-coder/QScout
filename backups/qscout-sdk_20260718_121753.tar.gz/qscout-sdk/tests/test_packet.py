"""Tests for RBPacket class."""

import unittest

from qscout.packet import RBPacket
from qscout.protocol import build_packet, HEADER
from qscout.exceptions import QScoutChecksumError, QScoutProtocolError


class TestRBPacket(unittest.TestCase):

    def test_create_minimal(self):
        p = RBPacket(order_id=1, action=0x05)
        self.assertEqual(p.order_id, 1)
        self.assertEqual(p.action, 0x05)
        self.assertEqual(p.payload, b"")
        self.assertEqual(p.size, 6)

    def test_create_with_payload(self):
        p = RBPacket(order_id=2, action=0x02, payload=b"\x04\x00\x64")
        self.assertEqual(p.size, 9)

    def test_to_bytes_header(self):
        p = RBPacket(order_id=0x01, action=0x05)
        raw = p.to_bytes()
        self.assertEqual(raw[:2], HEADER)

    def test_to_bytes_length(self):
        p = RBPacket(order_id=0x01, action=0x05)
        raw = p.to_bytes()
        self.assertEqual(len(raw), 6)

    def test_roundtrip(self):
        original = RBPacket(order_id=0x03, action=0x02, payload=b"\x04\x00\x50")
        raw = original.to_bytes()
        restored = RBPacket.from_bytes(raw)
        self.assertEqual(original, restored)

    def test_from_bytes_invalid_header(self):
        with self.assertRaises(QScoutProtocolError):
            RBPacket.from_bytes(b"\x00\x00\x05\x01\x05\x00")

    def test_from_bytes_invalid_checksum(self):
        raw = build_packet(order_id=0x01, action=0x05)
        bad = raw[:-1] + bytes([(raw[-1] + 1) % 256])
        with self.assertRaises(QScoutChecksumError):
            RBPacket.from_bytes(bad)

    def test_from_bytes_too_short(self):
        with self.assertRaises(QScoutProtocolError):
            RBPacket.from_bytes(b"\x52\x42\x05")

    def test_equality(self):
        a = RBPacket(order_id=1, action=0x05)
        b = RBPacket(order_id=1, action=0x05)
        self.assertEqual(a, b)

    def test_inequality(self):
        a = RBPacket(order_id=1, action=0x05)
        b = RBPacket(order_id=2, action=0x05)
        self.assertNotEqual(a, b)

    def test_repr(self):
        p = RBPacket(order_id=1, action=0x05, payload=b"\xAA")
        r = repr(p)
        self.assertIn("order_id=1", r)
        self.assertIn("0x05", r)
        self.assertIn("AA", r)

    def test_slots_prevent_arbitrary_attributes(self):
        p = RBPacket(order_id=1, action=0x05)
        with self.assertRaises(AttributeError):
            p.nonexistent = True  # type: ignore


if __name__ == "__main__":
    unittest.main()
