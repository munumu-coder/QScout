"""Tests for Command class."""

import unittest

from qscout.command_map import (
    CommandType,
    GET_DEVICE_INFO,
    GET_ULTRASONIC,
    SET_LED,
    SET_BUZZER,
)
from qscout.commands import Command
from qscout.exceptions import QScoutProtocolError


class TestCommandCreation(unittest.TestCase):

    def test_create_get_command(self):
        c = Command(GET_DEVICE_INFO)
        self.assertEqual(c.name, "GET_DEVICE_INFO")
        self.assertEqual(c.action, 0x01)
        self.assertTrue(c.is_get)
        self.assertFalse(c.is_set)
        self.assertEqual(c.payload, b"")

    def test_create_set_command(self):
        c = Command(SET_LED, payload=b"\x04\xFF\x00\x00")
        self.assertEqual(c.name, "SET_LED")
        self.assertEqual(c.action, 0x10)
        self.assertTrue(c.is_set)
        self.assertEqual(c.payload, b"\x04\xFF\x00\x00")

    def test_default_order_id_is_zero(self):
        c = Command(GET_DEVICE_INFO)
        self.assertEqual(c.order_id, 0)

    def test_custom_order_id(self):
        c = Command(GET_DEVICE_INFO, order_id=5)
        self.assertEqual(c.order_id, 5)


class TestCommandValidation(unittest.TestCase):

    def test_get_with_payload_ok(self):
        c = Command(GET_ULTRASONIC, payload=b"\x01")
        self.assertEqual(c.payload, b"\x01")
        self.assertTrue(c.is_get)

    def test_set_without_payload_ok(self):
        c = Command(SET_BUZZER)
        self.assertEqual(c.payload, b"")

    def test_wrong_definition_type(self):
        with self.assertRaises(QScoutProtocolError):
            Command("not a CommandDef")  # type: ignore

    def test_payload_wrong_type(self):
        with self.assertRaises(QScoutProtocolError):
            Command(SET_LED, payload="hello")  # type: ignore


class TestCommandRepresentation(unittest.TestCase):

    def test_repr_get(self):
        c = Command(GET_DEVICE_INFO)
        r = repr(c)
        self.assertIn("GET_DEVICE_INFO", r)
        self.assertIn("0x01", r)
        self.assertIn("GET", r)

    def test_repr_set_with_payload(self):
        c = Command(SET_LED, payload=b"\x04\xFF\x00\x00")
        r = repr(c)
        self.assertIn("04 FF 00 00", r)

    def test_repr_set_empty_payload(self):
        c = Command(SET_BUZZER)
        r = repr(c)
        self.assertIn("(none)", r)


class TestCommandEquality(unittest.TestCase):

    def test_equal(self):
        a = Command(SET_LED, payload=b"\x04\xFF")
        b = Command(SET_LED, payload=b"\x04\xFF")
        self.assertEqual(a, b)

    def test_different_payload(self):
        a = Command(SET_LED, payload=b"\x04\xFF")
        b = Command(SET_LED, payload=b"\x04\x00")
        self.assertNotEqual(a, b)

    def test_different_order_id(self):
        a = Command(GET_DEVICE_INFO, order_id=1)
        b = Command(GET_DEVICE_INFO, order_id=2)
        self.assertNotEqual(a, b)

    def test_not_equal_to_non_command(self):
        c = Command(GET_DEVICE_INFO)
        self.assertNotEqual(c, "not a command")


class TestCommandProperties(unittest.TestCase):

    def test_is_get(self):
        c = Command(GET_ULTRASONIC)
        self.assertTrue(c.is_get)
        self.assertFalse(c.is_set)

    def test_is_set(self):
        c = Command(SET_LED, payload=b"\x04\x00\x00\x00")
        self.assertTrue(c.is_set)
        self.assertFalse(c.is_get)

    def test_cmd_type_property(self):
        c = Command(GET_DEVICE_INFO)
        self.assertIs(c.cmd_type, CommandType.GET)


if __name__ == "__main__":
    unittest.main()
