"""Tests for sensor commands."""

import unittest

from qscout import sensors
from qscout.command_map import GET_ULTRASONIC


class TestGetUltrasonic(unittest.TestCase):

    def test_payload_format(self):
        cmd = sensors.get_ultrasonic(port=1)
        self.assertEqual(cmd.action, 0xA1)
        self.assertEqual(cmd.definition, GET_ULTRASONIC)
        self.assertEqual(cmd.payload, b"\x01")

    def test_onboard_port(self):
        cmd = sensors.get_ultrasonic(port=-4)
        self.assertEqual(cmd.payload[0], 0xFC)

    def test_command_is_get(self):
        cmd = sensors.get_ultrasonic(port=1)
        self.assertTrue(cmd.is_get)


class TestParseUltrasonicResponse(unittest.TestCase):

    def test_parse_real_response(self):
        """Real captured response: 52 42 08 02 01 09 C4 6C → 2500mm."""
        raw = bytes([0x52, 0x42, 0x08, 0x02, 0x01, 0x09, 0xC4, 0x6C])
        distance = sensors.parse_ultrasonic_response(raw)
        self.assertEqual(distance, 2500)

    def test_parse_zero(self):
        raw = bytes([0x52, 0x42, 0x08, 0x00, 0x01, 0x00, 0x00, 0x00])
        distance = sensors.parse_ultrasonic_response(raw)
        self.assertEqual(distance, 0)

    def test_parse_max(self):
        raw = bytes([0x52, 0x42, 0x08, 0x00, 0x01, 0xFF, 0xFF, 0x00])
        distance = sensors.parse_ultrasonic_response(raw)
        self.assertEqual(distance, 65535)

    def test_parse_too_short(self):
        with self.assertRaises(ValueError):
            sensors.parse_ultrasonic_response(b"\x52\x42\x08")


if __name__ == "__main__":
    unittest.main()
