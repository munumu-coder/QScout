"""Tests for actuator commands."""

import struct
import unittest

from qscout import actuators
from qscout.command_map import SET_BUZZER, SET_LED, SET_MOTOR, SET_MOVE


class TestLED(unittest.TestCase):

    def test_payload_format(self):
        cmd = actuators.led(port=-4, r=255, g=0, b=0)
        self.assertEqual(cmd.action, 0x10)
        self.assertEqual(cmd.definition, SET_LED)
        self.assertEqual(cmd.payload, b"\xFC\xFF\x00\x00")

    def test_payload_green(self):
        cmd = actuators.led(port=-4, r=0, g=255, b=0)
        self.assertEqual(cmd.payload, b"\xFC\x00\xFF\x00")

    def test_payload_off(self):
        cmd = actuators.led(port=-4, r=0, g=0, b=0)
        self.assertEqual(cmd.payload, b"\xFC\x00\x00\x00")

    def test_external_port(self):
        cmd = actuators.led(port=1, r=100, g=100, b=100)
        self.assertEqual(cmd.payload[0], 1)

    def test_invalid_rgb_negative(self):
        with self.assertRaises(ValueError):
            actuators.led(port=1, r=-1, g=0, b=0)

    def test_invalid_rgb_over_255(self):
        with self.assertRaises(ValueError):
            actuators.led(port=1, r=0, g=0, b=256)


class TestMotor(unittest.TestCase):

    def test_payload_format(self):
        cmd = actuators.motor(port=-1, speed=80)
        self.assertEqual(cmd.action, 0x11)
        self.assertEqual(cmd.definition, SET_MOTOR)
        self.assertEqual(cmd.payload, b"\xFF\x50")

    def test_speed_clamped(self):
        cmd = actuators.motor(port=1, speed=200)
        self.assertEqual(cmd.payload[1], 100)

    def test_speed_negative_clamped(self):
        cmd = actuators.motor(port=1, speed=-200)
        self.assertEqual(cmd.payload[1], (-100) & 0xFF)

    def test_stop(self):
        cmd = actuators.motor(port=-1, speed=0)
        self.assertEqual(cmd.payload[1], 0)


class TestMove(unittest.TestCase):

    def test_payload_format(self):
        cmd = actuators.move(left_speed=50, right_speed=50)
        self.assertEqual(cmd.action, 0x11)
        self.assertEqual(cmd.definition, SET_MOVE)
        self.assertEqual(len(cmd.payload), 3)
        self.assertEqual(cmd.payload[0], 0x00)
        self.assertEqual(cmd.payload[1], 50)
        self.assertEqual(cmd.payload[2], 50)

    def test_different_speeds(self):
        cmd = actuators.move(left_speed=80, right_speed=-80)
        self.assertEqual(cmd.payload[1], 80)
        self.assertEqual(cmd.payload[2], (-80) & 0xFF)

    def test_speed_clamped(self):
        cmd = actuators.move(left_speed=150, right_speed=150)
        self.assertEqual(cmd.payload[1], 100)
        self.assertEqual(cmd.payload[2], 100)

    def test_motor_vs_move_different_payloads(self):
        m = actuators.motor(port=-1, speed=50)
        mv = actuators.move(left_speed=50, right_speed=50)
        self.assertEqual(m.action, mv.action)
        self.assertNotEqual(m.payload, mv.payload)


class TestBuzzer(unittest.TestCase):

    def test_payload_format(self):
        cmd = actuators.buzzer(frequency=440, duration_ms=500)
        self.assertEqual(cmd.action, 0x13)
        self.assertEqual(cmd.definition, SET_BUZZER)
        self.assertEqual(len(cmd.payload), 5)
        self.assertEqual(cmd.payload[0], 0)

    def test_frequency_in_payload(self):
        cmd = actuators.buzzer(frequency=1000, duration_ms=100)
        freq = struct.unpack_from("<H", cmd.payload, 1)[0]
        self.assertEqual(freq, 1000)

    def test_duration_in_payload(self):
        cmd = actuators.buzzer(frequency=440, duration_ms=2000)
        dur = struct.unpack_from("<H", cmd.payload, 3)[0]
        self.assertEqual(dur, 2000)

    def test_invalid_frequency(self):
        with self.assertRaises(ValueError):
            actuators.buzzer(frequency=70000, duration_ms=100)

    def test_invalid_duration(self):
        with self.assertRaises(ValueError):
            actuators.buzzer(frequency=440, duration_ms=70000)


if __name__ == "__main__":
    unittest.main()
