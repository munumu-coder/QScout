# QScout SDK

Python SDK para control del robot **Robobloq Q-Scout RB-00002** desde Linux vía UART/USB.

## Requisitos

- Python ≥ 3.10
- Linux (probado en Ubuntu/Debian)
- pyserial

## Instalación

```bash
pip install -e .
```

## Uso rápido

```python
from qscout import QScout

with QScout("/dev/ttyUSB0") as robot:
    # LED rojo en puerto M4
    robot.led(-4, 255, 0, 0)

    # Mover robot
    robot.move(50, 50)

    # Leer sensor ultrasónico
    distance = robot.get_ultrasonic(1)
    print(f"Distancia: {distance} mm")

    # Buzzer
    robot.buzzer(440, 500)

    # Parar
    robot.stop()
```

### Comandos disponibles (confirmados experimentalmente)

| Método | Descripción | Tipo |
|--------|-------------|:----:|
| `robot.led(port, r, g, b)` | Color LED RGB | SET |
| `robot.motor(port, speed)` | Motor individual | SET |
| `robot.move(left, right)` | Movimiento dual motor | SET |
| `robot.stop()` | Parar ambos motores | SET |
| `robot.buzzer(freq, duration)` | Tono buzzer | SET |
| `robot.get_ultrasonic(port)` | Distancia ultrasónica (mm) | GET |

**Nota:** Solo comandos validados experimentalmente. Sensores/actuadores pendientes no están implementados.

## Tests

```bash
PYTHONPATH=src python3 -m unittest discover -s tests
```

## Arquitectura

```
┌──────────────────┐
│   robot.led()    │  ← API de usuario
└────────┬─────────┘
         │
┌────────▼─────────┐
│      QScout      │  ← Fachada
└────────┬─────────┘
         │
┌────────▼─────────┐
│  actuators.py    │  ← Construcción de payloads
│  sensors.py      │
└────────┬─────────┘
         │
┌────────▼─────────┐
│    Command       │  ← Intención abstracta
│  command_map.py  │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  build_packet()  │  ← Protocolo RB genérico
│  protocol.py     │
└────────┬─────────┘
         │
┌────────▼─────────┐
│ QScoutConnection │  ← Transporte UART
│  connection.py   │
└──────────────────┘
```

| Módulo | Capa | Responsabilidad |
|--------|------|-----------------|
| `connection.py` | SDK-01 | Transporte UART |
| `protocol.py` | SDK-01 | Paquetes RB genéricos |
| `packet.py` | SDK-01 | Representación RBPacket |
| `command_map.py` | SDK-02 | Definición de comandos |
| `commands.py` | SDK-02 | Abstracción Command |
| `actuators.py` | SDK-02 | Payloads de escritura |
| `sensors.py` | SDK-02 | Payloads de lectura |
| `__init__.py` | SDK-02 | Fachada QScout |

## Estructura

```
qscout/
    __init__.py       # QScout facade + Order ID manager
    connection.py     # UART transport (SDK-01)
    packet.py         # RBPacket (SDK-01)
    protocol.py       # Checksum, build, parse (SDK-01)
    commands.py       # Command abstraction (SDK-02)
    command_map.py    # Action codes registry (SDK-02)
    actuators.py      # Actuator payloads (SDK-02)
    sensors.py        # Sensor payloads (SDK-02)
    exceptions.py     # SDK exceptions
tests/
    test_checksum.py
    test_packet.py
    test_command_map.py
    test_commands.py
    test_actuators.py
    test_sensors.py
    test_facade.py
```
