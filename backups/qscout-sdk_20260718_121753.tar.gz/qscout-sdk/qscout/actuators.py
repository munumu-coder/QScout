"""Actuator commands for the QScout robot.

Each function builds the correct payload for its command and returns
a ``Command`` ready to be sent. They do NOT send anything themselves —
the ``QScout`` facade is responsible for transmission.
"""

from __future__ import annotations

import struct

from .command_map import SET_BUZZER, SET_LED, SET_MOTOR, SET_MOVE
from .commands import Command


def _clamp_speed(v: int) -> int:
    """Clamp motor speed to [-100, 100] per protocol specification."""
    return max(-100, min(100, v))


def _clamp_port(v: int) -> int:
    """Clamp port to signed 8-bit range [-128, 127]."""
    return max(-128, min(127, v))


def led(port: int, r: int, g: int, b: int) -> Command:
    """Build a SET_LED command.

    Args:
        port: port number (negative = on-board: -1=M1, -2=M2, -3=M3, -4=M4).
        r: red component (0-255).
        g: green component (0-255).
        b: blue component (0-255).

    Returns:
        Command ready to send.
    """
    if not all(0 <= c <= 255 for c in (r, g, b)):
        raise ValueError(f"RGB values must be 0..255, got r={r}, g={g}, b={b}")
    payload = struct.pack("<bBBB", _clamp_port(port), r & 0xFF, g & 0xFF, b & 0xFF)
    return Command(SET_LED, payload=payload)


def motor(port: int, speed: int) -> Command:
    """Build a SET_MOTOR command (single motor).

    Args:
        port: port number (negative = on-board motor).
        speed: speed -100..100 (clamped automatically).

    Returns:
        Command ready to send.
    """
    payload = struct.pack("<bb", _clamp_port(port), _clamp_speed(speed))
    return Command(SET_MOTOR, payload=payload)


def move(left_speed: int, right_speed: int) -> Command:
    """Build a SET_MOVE command (dual motor drive).

    Args:
        left_speed: left motor speed -100..100.
        right_speed: right motor speed -100..100.

    Returns:
        Command ready to send.
    """
    payload = struct.pack(
        "<bbb", 0, _clamp_speed(left_speed), _clamp_speed(right_speed)
    )
    return Command(SET_MOVE, payload=payload)


def buzzer(frequency: int, duration_ms: int) -> Command:
    """Build a SET_BUZZER command.

    Args:
        frequency: tone frequency in Hz (0-65535).
        duration_ms: duration in milliseconds (0-65535).

    Returns:
        Command ready to send. Robot returns ACK response.
    """
    if not (0 <= frequency <= 0xFFFF):
        raise ValueError(f"frequency must be 0..65535, got {frequency}")
    if not (0 <= duration_ms <= 0xFFFF):
        raise ValueError(f"duration_ms must be 0..65535, got {duration_ms}")
    payload = struct.pack("<BHH", 0, frequency & 0xFFFF, duration_ms & 0xFFFF)
    return Command(SET_BUZZER, payload=payload)
