"""Command abstraction layer for the QScout SDK.

A ``Command`` represents an *intention* to perform an action on the robot.
An ``RBPacket`` represents the *bytes* that carry that intention over UART.

This separation keeps the "what we want to do" independent from
"how we transmit it".
"""

from __future__ import annotations

from .command_map import CommandDef, CommandType
from .exceptions import QScoutProtocolError


class Command:
    """A pending command to be sent to the QScout robot.

    Attributes:
        definition: the ``CommandDef`` describing this command.
        order_id:   correlation id for request-response matching (0 = auto).
        payload:    command-specific data bytes.
    """

    __slots__ = ("definition", "order_id", "payload")

    def __init__(
        self,
        definition: CommandDef,
        payload: bytes = b"",
        order_id: int = 0,
    ) -> None:
        self.definition = definition
        self.order_id = order_id
        self.payload = payload
        self._validate()

    # -- read-only helpers ---------------------------------------------------

    @property
    def name(self) -> str:
        return self.definition.name

    @property
    def action(self) -> int:
        return self.definition.action

    @property
    def cmd_type(self) -> CommandType:
        return self.definition.cmd_type

    @property
    def is_get(self) -> bool:
        return self.cmd_type is CommandType.GET

    @property
    def is_set(self) -> bool:
        return self.cmd_type is CommandType.SET

    # -- validation ----------------------------------------------------------

    def _validate(self) -> None:
        if not isinstance(self.definition, CommandDef):
            raise QScoutProtocolError(
                f"definition must be CommandDef, got {type(self.definition).__name__}"
            )
        if not isinstance(self.payload, (bytes, bytearray)):
            raise QScoutProtocolError(
                f"payload must be bytes, got {type(self.payload).__name__}"
            )

    # -- representation ------------------------------------------------------

    def __repr__(self) -> str:
        payload_hex = " ".join(f"{b:02X}" for b in self.payload) or "(none)"
        return (
            f"Command({self.name}, 0x{self.action:02X}, "
            f"{self.cmd_type.value}, payload=[{payload_hex}])"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Command):
            return NotImplemented
        return (
            self.definition == other.definition
            and self.order_id == other.order_id
            and self.payload == other.payload
        )
