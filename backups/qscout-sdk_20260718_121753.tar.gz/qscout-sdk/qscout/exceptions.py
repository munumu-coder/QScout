"""QScout SDK exceptions."""


class QScoutError(Exception):
    """Base exception for QScout SDK."""


class QScoutConnectionError(QScoutError):
    """Raised when UART connection fails."""


class QScoutProtocolError(QScoutError):
    """Raised when packet structure is invalid."""


class QScoutChecksumError(QScoutError):
    """Raised when packet checksum does not match."""
