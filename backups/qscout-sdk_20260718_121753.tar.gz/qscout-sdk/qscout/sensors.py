"""Sensor commands for the QScout robot.

Each function builds the correct payload for its command and returns
a ``Command`` ready to be sent. They do NOT send anything themselves —
the ``QScout`` facade is responsible for transmission and response parsing.
"""

from __future__ import annotations

import struct

from .command_map import GET_ULTRASONIC
from .commands import Command


def _clamp_port(v: int) -> int:
    """Clamp port to signed 8-bit range [-128, 127]."""
    return max(-128, min(127, v))


def get_ultrasonic(port: int) -> Command:
    """Build a GET_ULTRASONIC command.

    Args:
        port: port number where the ultrasonic sensor is connected.

    Returns:
        Command ready to send. Response is parsed by QScout.
    """
    payload = struct.pack("<b", _clamp_port(port))
    return Command(GET_ULTRASONIC, payload=payload)


def parse_ultrasonic_response(data: bytes) -> int:
    """Parse distance in mm from a raw response packet.

    The response payload carries the distance as a big-endian 16-bit
    unsigned integer at bytes [5..6] of the full packet.

    Args:
        data: raw response bytes (full RB packet).

    Returns:
        Distance in millimetres.

    Raises:
        ValueError: if the response is too short.
    """
    if len(data) < 7:
        raise ValueError(f"Response too short to parse ultrasonic: {len(data)} bytes")
    return data[5] * 256 + data[6]
