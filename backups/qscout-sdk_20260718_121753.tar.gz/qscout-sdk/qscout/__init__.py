"""QScout SDK — Python library for Robobloq Q-Scout (Linux)."""

from . import actuators, sensors
from .command_map import CommandDef, CommandType, get_command, list_commands
from .commands import Command
from .connection import QScoutConnection
from .exceptions import (
    QScoutChecksumError,
    QScoutConnectionError,
    QScoutError,
    QScoutProtocolError,
)
from .packet import RBPacket
from .protocol import (
    build_packet,
    calculate_checksum,
    parse_packet,
    receive_packet,
    validate_checksum,
)


class _OrderIdManager:
    """Generates sequential Order IDs for request-response correlation.

    IDs cycle from 2 to 254, skipping 0 (reserved for unsolicited reports).
    """

    def __init__(self) -> None:
        self._next = 2

    def next(self) -> int:
        """Return the next Order ID and advance the counter."""
        oid = self._next
        self._next += 1
        if self._next > 254:
            self._next = 2
        return oid


class QScout:
    """Main entry point for the QScout SDK.

    Provides high-level methods for controlling the robot without
    requiring knowledge of the RB protocol.

    Usage::

        with QScout("/dev/ttyUSB0") as robot:
            robot.led(-4, 255, 0, 0)   # red LED on port M4
            robot.move(50, 50)          # drive forward
            dist = robot.get_ultrasonic(1)
            robot.stop()
    """

    def __init__(
        self,
        port: str = "/dev/ttyUSB0",
        baudrate: int = 115200,
        timeout: float = 1.0,
    ) -> None:
        self._connection = QScoutConnection(port, baudrate, timeout)
        self._order_ids = _OrderIdManager()

    @property
    def connection(self) -> QScoutConnection:
        """Underlying UART connection (for advanced use)."""
        return self._connection

    def connect(self) -> None:
        """Open the connection to the robot."""
        self._connection.connect()

    def disconnect(self) -> None:
        """Close the connection to the robot."""
        self._connection.disconnect()

    # -- actuator commands (confirmed) ----------------------------------------

    def led(self, port: int, r: int, g: int, b: int) -> None:
        """Set RGB LED colour on *port*.

        Args:
            port: port number (negative = on-board: -1..-4).
            r, g, b: colour components 0-255.
        """
        cmd = actuators.led(port, r, g, b)
        self._send(cmd)

    def motor(self, port: int, speed: int) -> None:
        """Set single motor speed on *port*.

        Args:
            port: motor port (negative = on-board: -1..-4).
            speed: -100..100 (clamped automatically).
        """
        cmd = actuators.motor(port, speed)
        self._send(cmd)

    def move(self, left_speed: int, right_speed: int) -> None:
        """Drive robot with independent left/right motor speeds.

        Args:
            left_speed: left motor -100..100.
            right_speed: right motor -100..100.
        """
        cmd = actuators.move(left_speed, right_speed)
        self._send(cmd)

    def stop(self) -> None:
        """Stop both motors."""
        self.move(0, 0)

    def buzzer(self, frequency: int, duration_ms: int) -> None:
        """Play a tone on the buzzer.

        Args:
            frequency: Hz (0-65535).
            duration_ms: milliseconds (0-65535).

        Note: Returns an ACK response from the robot.
        """
        cmd = actuators.buzzer(frequency, duration_ms)
        self._send(cmd)

    # -- sensor commands (confirmed) ------------------------------------------

    def get_ultrasonic(self, port: int) -> int:
        """Read ultrasonic distance sensor.

        Args:
            port: port where the sensor is connected.

        Returns:
            Distance in millimetres.

        Raises:
            QScoutProtocolError: if the response is malformed.
        """
        cmd = sensors.get_ultrasonic(port)
        raw = self._send_receive(cmd)
        return sensors.parse_ultrasonic_response(raw)

    # -- internal ------------------------------------------------------------

    def _send(self, cmd: Command) -> None:
        """Send a command (fire-and-forget)."""
        oid = self._order_ids.next()
        cmd.order_id = oid
        raw = build_packet(oid, cmd.action, cmd.payload)
        self._connection.send(raw)

    def _send_receive(self, cmd: Command) -> bytes:
        """Send a command and read the response."""
        oid = self._order_ids.next()
        cmd.order_id = oid
        raw = build_packet(oid, cmd.action, cmd.payload)
        self._connection.send(raw)
        return receive_packet_raw(self._connection)

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> "QScout":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        return f"QScout({self._connection!r})"


def receive_packet_raw(connection) -> tuple[int, int, bytes]:
    """Read one complete RB packet, returning (order_id, action, payload)."""
    return receive_packet(connection)


__all__ = [
    "QScout",
    "QScoutConnection",
    "QScoutError",
    "QScoutConnectionError",
    "QScoutProtocolError",
    "QScoutChecksumError",
    "RBPacket",
    "Command",
    "CommandDef",
    "CommandType",
    "get_command",
    "list_commands",
    "build_packet",
    "calculate_checksum",
    "parse_packet",
    "receive_packet",
    "validate_checksum",
    "actuators",
    "sensors",
]
