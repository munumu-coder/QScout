"""UART connection to the QScout robot."""

from __future__ import annotations

from .exceptions import QScoutConnectionError

_DEFAULT_BAUDRATE = 115200


class QScoutConnection:
    """Thin wrapper around pyserial for raw byte transport.

    This class knows nothing about the RB protocol.
    It opens a serial port and provides send/receive primitives.
    """

    def __init__(
        self,
        port: str = "/dev/ttyUSB0",
        baudrate: int = _DEFAULT_BAUDRATE,
        timeout: float = 1.0,
    ) -> None:
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self._serial = None

    # -- lifecycle -----------------------------------------------------------

    def connect(self) -> None:
        """Open the serial port."""
        try:
            import serial

            self._serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout,
                bytesize=8,
                parity="N",
                stopbits=1,
            )
        except ImportError as exc:
            raise QScoutConnectionError("pyserial is not installed") from exc
        except Exception as exc:
            raise QScoutConnectionError(f"Cannot open {self.port}: {exc}") from exc

    def disconnect(self) -> None:
        """Close the serial port."""
        if self._serial and self._serial.is_open:
            self._serial.close()
        self._serial = None

    # -- transport -----------------------------------------------------------

    def send(self, data: bytes) -> None:
        """Write raw bytes to the serial port."""
        if not self._serial or not self._serial.is_open:
            raise QScoutConnectionError("Not connected")
        self._serial.write(data)

    def receive(self, size: int = 64) -> bytes:
        """Read raw bytes from the serial port."""
        if not self._serial or not self._serial.is_open:
            raise QScoutConnectionError("Not connected")
        return self._serial.read(size)

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> "QScoutConnection":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        state = "connected" if self._serial and self._serial.is_open else "disconnected"
        return f"QScoutConnection(port={self.port!r}, baudrate={self.baudrate}, {state})"
