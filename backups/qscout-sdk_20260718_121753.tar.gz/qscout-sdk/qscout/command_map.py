"""Centralized definition of all RB protocol command action codes."""

from enum import Enum


class CommandType(Enum):
    """Operation type for a command."""

    GET = "GET"
    SET = "SET"


class CommandDef:
    """Definition of a single RB protocol command.

    Attributes:
        name:       human-readable command name (e.g. "GET_DEVICE_INFO").
        action:     action code byte (0x00..0xFF).
        cmd_type:   GET (read from robot) or SET (write to robot).
        validated:  True if this command was tested against real hardware.
        description: brief explanation of what the command does.
    """

    __slots__ = ("name", "action", "cmd_type", "validated", "description")

    def __init__(
        self,
        name: str,
        action: int,
        cmd_type: CommandType,
        validated: bool = False,
        description: str = "",
    ) -> None:
        self.name = name
        self.action = action
        self.cmd_type = cmd_type
        self.validated = validated
        self.description = description

    def __repr__(self) -> str:
        status = "CONFIRMED" if self.validated else "PENDING"
        return (
            f"CommandDef({self.name}, 0x{self.action:02X}, "
            f"{self.cmd_type.value}, {status})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CommandDef):
            return NotImplemented
        return (
            self.name == other.name
            and self.action == other.action
            and self.cmd_type == other.cmd_type
        )

    def __hash__(self) -> int:
        return hash((self.name, self.action, self.cmd_type))


# ─── GET commands (sensors / information) ────────────────────────────────────

GET_DEVICE_INFO = CommandDef(
    name="GET_DEVICE_INFO",
    action=0x01,
    cmd_type=CommandType.GET,
    validated=True,
    description="Read hardware and firmware version",
)

GET_INTERFACE_INFO = CommandDef(
    name="GET_INTERFACE_INFO",
    action=0x02,
    cmd_type=CommandType.GET,
    validated=True,
    description="Read sensor type connected to a port",
)

GET_ALL_INTERFACE_INFO = CommandDef(
    name="GET_ALL_INTERFACE_INFO",
    action=0x03,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read sensor type on all ports",
)

GET_MOTOR_INTERFACE_INFO = CommandDef(
    name="GET_MOTOR_INTERFACE_INFO",
    action=0x04,
    cmd_type=CommandType.GET,
    validated=True,
    description="Read motor configuration",
)

GET_USER_INTERFACE_INFO = CommandDef(
    name="GET_USER_INTERFACE_INFO",
    action=0x05,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read user-configured interface info",
)

GET_ULTRASONIC = CommandDef(
    name="GET_ULTRASONIC",
    action=0xA1,
    cmd_type=CommandType.GET,
    validated=True,
    description="Read ultrasonic distance sensor (mm)",
)

GET_BUTTON = CommandDef(
    name="GET_BUTTON",
    action=0xA2,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read button state",
)

GET_VOLTAGE = CommandDef(
    name="GET_VOLTAGE",
    action=0xA3,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read battery voltage",
)

GET_LINE_VALUE = CommandDef(
    name="GET_LINE_VALUE",
    action=0xA4,
    cmd_type=CommandType.GET,
    validated=True,
    description="Read line-tracking sensor value",
)

GET_TEMP_HUMIDITY = CommandDef(
    name="GET_TEMP_HUMIDITY",
    action=0xA5,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read temperature and humidity sensor",
)

GET_LIGHT = CommandDef(
    name="GET_LIGHT",
    action=0xA6,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read light sensor",
)

GET_VOICE = CommandDef(
    name="GET_VOICE",
    action=0xA7,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read voice sensor",
)

GET_INFRARED = CommandDef(
    name="GET_INFRARED",
    action=0xA8,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read infrared sensor",
)

GET_GYRO = CommandDef(
    name="GET_GYRO",
    action=0xA9,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read gyroscope / accelerometer",
)

GET_COLOR = CommandDef(
    name="GET_COLOR",
    action=0xAA,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read color sensor (RGB or greyscale)",
)

GET_TOUCH_BUTTON = CommandDef(
    name="GET_TOUCH_BUTTON",
    action=0xAB,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read capacitive touch button",
)

GET_TEMP_DUAL = CommandDef(
    name="GET_TEMP_DUAL",
    action=0xAC,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read dual temperature sensor",
)

GET_SIX_LINE = CommandDef(
    name="GET_SIX_LINE",
    action=0xAD,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read 6-channel line sensor",
)

GET_ROCKER = CommandDef(
    name="GET_ROCKER",
    action=0xAE,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read rocker / joystick module",
)

GET_FLAME = CommandDef(
    name="GET_FLAME",
    action=0xAF,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read flame sensor",
)

GET_GAS = CommandDef(
    name="GET_GAS",
    action=0xB0,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read gas sensor",
)

GET_SPIRAL_POT = CommandDef(
    name="GET_SPIRAL_POT",
    action=0xB1,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read spiral potentiometer",
)

GET_LINE_POT = CommandDef(
    name="GET_LINE_POT",
    action=0xB2,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read linear potentiometer",
)

GET_EXT_IO_INPUT = CommandDef(
    name="GET_EXT_IO_INPUT",
    action=0xB4,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read extended I/O input",
)

GET_EXT_APC = CommandDef(
    name="GET_EXT_APC",
    action=0xB5,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read extended APC value",
)

GET_EXT_TEMP_HUMI = CommandDef(
    name="GET_EXT_TEMP_HUMI",
    action=0xB6,
    cmd_type=CommandType.GET,
    validated=False,
    description="Read extended temperature/humidity",
)

# ─── SET commands (actuators / outputs) ──────────────────────────────────────

SET_LED = CommandDef(
    name="SET_LED",
    action=0x10,
    cmd_type=CommandType.SET,
    validated=True,
    description="Set RGB LED color on a port",
)

SET_MOTOR = CommandDef(
    name="SET_MOTOR",
    action=0x11,
    cmd_type=CommandType.SET,
    validated=True,
    description="Set single motor speed on a port",
)

SET_MOVE = CommandDef(
    name="SET_MOVE",
    action=0x11,
    cmd_type=CommandType.SET,
    validated=True,
    description="Set dual motor speeds (drive robot)",
)

SET_ULTRASONIC_LIGHT = CommandDef(
    name="SET_ULTRASONIC_LIGHT",
    action=0x12,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set ultrasonic module LED color",
)

SET_BUZZER = CommandDef(
    name="SET_BUZZER",
    action=0x13,
    cmd_type=CommandType.SET,
    validated=True,
    description="Play buzzer tone at frequency/duration",
)

SET_MATRIX = CommandDef(
    name="SET_MATRIX",
    action=0x14,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set 8x8 LED matrix pattern",
)

SET_WORK_MODE = CommandDef(
    name="SET_WORK_MODE",
    action=0x18,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set port work mode (input/output/pwm)",
)

SET_STEERING_ENGINE = CommandDef(
    name="SET_STEERING_ENGINE",
    action=0x19,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set steering servo angle",
)

SET_OUT_ENGINE = CommandDef(
    name="SET_OUT_ENGINE",
    action=0x1A,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set external motor speed/direction",
)

SET_RGB_LED_MATRIX = CommandDef(
    name="SET_RGB_LED_MATRIX",
    action=0x1B,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set RGB LED matrix colors",
)

SET_MP3 = CommandDef(
    name="SET_MP3",
    action=0x1C,
    cmd_type=CommandType.SET,
    validated=False,
    description="Control MP3 player module",
)

SET_FOUR_DIGIT = CommandDef(
    name="SET_FOUR_DIGIT",
    action=0x1E,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set 4-digit 7-segment display",
)

SET_FOUR_RGB_LED = CommandDef(
    name="SET_FOUR_RGB_LED",
    action=0x1F,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set 4 RGB LED module colors",
)

SET_FAN = CommandDef(
    name="SET_FAN",
    action=0x20,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set fan speed and direction",
)

SET_EXT_IO_OUTPUT = CommandDef(
    name="SET_EXT_IO_OUTPUT",
    action=0x21,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set extended I/O output",
)

SET_EXT_SERVO_DEGREE = CommandDef(
    name="SET_EXT_SERVO_DEGREE",
    action=0x22,
    cmd_type=CommandType.SET,
    validated=False,
    description="Set external servo angle",
)

# ─── Lookup tables ───────────────────────────────────────────────────────────

_ALL_COMMANDS: dict[str, CommandDef] = {}
_BY_ACTION: dict[int, list[CommandDef]] = {}

for _obj in list(globals().values()):
    if isinstance(_obj, CommandDef):
        _ALL_COMMANDS[_obj.name] = _obj
        _BY_ACTION.setdefault(_obj.action, []).append(_obj)

del _obj


def get_command(name: str) -> CommandDef:
    """Return the CommandDef for *name*, or raise KeyError."""
    try:
        return _ALL_COMMANDS[name]
    except KeyError:
        raise KeyError(f"Unknown command: {name!r}") from None


def get_commands_by_action(action: int) -> list[CommandDef]:
    """Return all CommandDefs that share *action* code (may be 1 or 2)."""
    return _BY_ACTION.get(action, [])


def list_commands() -> list[CommandDef]:
    """Return all registered command definitions, sorted by action code."""
    return sorted(_ALL_COMMANDS.values(), key=lambda c: c.action)
