"""RB protocol utilities: checksum, packet building and parsing."""

from .exceptions import QScoutChecksumError, QScoutProtocolError

HEADER = bytes([0x52, 0x42])
MIN_PACKET_SIZE = 6


def calculate_checksum(data: bytes | bytearray) -> int:
    """Sum of all bytes modulo 256."""
    return sum(data) % 256


def validate_checksum(packet: bytes | bytearray) -> bool:
    """Return True if the last byte equals the checksum of the rest."""
    if len(packet) < MIN_PACKET_SIZE:
        return False
    return calculate_checksum(packet[:-1]) == packet[-1]


def build_packet(order_id: int, action: int, payload: bytes = b"") -> bytes:
    """Build a complete RB packet with header, size, checksum.

    Structure: [RB 2B][size 1B][order_id 1B][action 1B][payload NB][checksum 1B]
    Size = total number of bytes in the entire packet (including header and checksum).
    Checksum = sum of all bytes except the checksum byte itself, mod 256.

    Raises:
        TypeError: if order_id/action are not int, or payload is not bytes.
        ValueError: if order_id or action are outside 0..255.
    """
    if not isinstance(order_id, int):
        raise TypeError(f"order_id must be int, got {type(order_id).__name__}")
    if not isinstance(action, int):
        raise TypeError(f"action must be int, got {type(action).__name__}")
    if not isinstance(payload, (bytes, bytearray)):
        raise TypeError(f"payload must be bytes, got {type(payload).__name__}")
    if not (0 <= order_id <= 255):
        raise ValueError(f"order_id must be 0..255, got {order_id}")
    if not (0 <= action <= 255):
        raise ValueError(f"action must be 0..255, got {action}")

    size = 6 + len(payload)
    body = bytes([size, order_id, action]) + payload
    full = HEADER + body
    checksum = calculate_checksum(full)
    return full + bytes([checksum])


def parse_packet(data: bytes | bytearray) -> tuple[int, int, bytes]:
    """Parse raw bytes into (order_id, action, payload).

    Raises QScoutProtocolError if header is wrong or data is too short.
    Raises QScoutChecksumError if checksum fails.
    """
    if len(data) < MIN_PACKET_SIZE:
        raise QScoutProtocolError(
            f"Packet too short: {len(data)} bytes (need >= {MIN_PACKET_SIZE})"
        )
    if data[0] != HEADER[0] or data[1] != HEADER[1]:
        raise QScoutProtocolError(
            f"Invalid header: 0x{data[0]:02X} 0x{data[1]:02X} "
            f"(expected 0x52 0x42)"
        )
    if not validate_checksum(data):
        raise QScoutChecksumError(
            f"Checksum mismatch: expected 0x{calculate_checksum(data[:-1]):02X}, "
            f"got 0x{data[-1]:02X}"
        )
    order_id = data[3]
    action = data[4]
    payload = bytes(data[5:-1])
    return order_id, action, payload


def receive_packet(connection) -> tuple[int, int, bytes]:
    """Read one complete RB packet from *connection*.

    *connection* must expose a ``receive(size) -> bytes`` method
    (e.g. ``QScoutConnection``).

    First reads 3 bytes (header + size), then reads the remaining
    bytes according to the size field, and finally parses the packet.

    Raises QScoutProtocolError on malformed data.
    Raises QScoutChecksumError on checksum mismatch.
    """
    header = connection.receive(3)
    if len(header) < 3:
        raise QScoutProtocolError("No data received (connection timeout?)")

    size = header[2]
    remaining = size - 3
    if remaining > 0:
        body = connection.receive(remaining)
        if len(body) < remaining:
            raise QScoutProtocolError(
                f"Incomplete packet: expected {remaining} more bytes, got {len(body)}"
            )
        full = header + body
    else:
        full = header

    return parse_packet(full)
