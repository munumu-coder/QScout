"""RB packet representation."""

from .exceptions import QScoutChecksumError, QScoutProtocolError
from .protocol import HEADER, build_packet, calculate_checksum, parse_packet


class RBPacket:
    """Represents one RB protocol packet.

    Stores only the variable fields: order_id, action, payload.
    Header (0x52 0x42), size, and checksum are computed dynamically
    on serialization (``to_bytes``) to avoid data inconsistency.
    """

    __slots__ = ("order_id", "action", "payload")

    def __init__(self, order_id: int, action: int, payload: bytes = b"") -> None:
        self.order_id = order_id
        self.action = action
        self.payload = payload

    # -- factories -----------------------------------------------------------

    @classmethod
    def from_bytes(cls, data: bytes | bytearray) -> "RBPacket":
        """Parse raw bytes into an RBPacket."""
        order_id, action, payload = parse_packet(data)
        return cls(order_id, action, payload)

    # -- serialization -------------------------------------------------------

    def to_bytes(self) -> bytes:
        """Serialize to wire format (header + size + body + checksum)."""
        return build_packet(self.order_id, self.action, self.payload)

    # -- helpers -------------------------------------------------------------

    @property
    def size(self) -> int:
        """Size field value: total bytes in packet."""
        return 6 + len(self.payload)

    def __repr__(self) -> str:
        payload_hex = " ".join(f"{b:02X}" for b in self.payload) or "(empty)"
        return (
            f"RBPacket(order_id={self.order_id}, action=0x{self.action:02X}, "
            f"payload=[{payload_hex}])"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RBPacket):
            return NotImplemented
        return (
            self.order_id == other.order_id
            and self.action == other.action
            and self.payload == other.payload
        )
