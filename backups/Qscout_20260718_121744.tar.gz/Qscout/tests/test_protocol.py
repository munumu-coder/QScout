"""Unit tests for qscout.protocol module."""

import unittest
from qscout.protocol import (
    Action, Port, OrderManager, sum_check, build_packet,
    parse_header, parse_order_id, parse_action, parse_length,
    parse_checksum_ok, extract_packets, build_set_led, build_set_motor,
    build_set_move, build_set_buzzer, _clamp_signed8, _clamp_speed,
    parse_ultrasonic, parse_voltage, parse_button, parse_light,
    parse_temp_humidity, parse_gyro, parse_rocker, parse_color_rgb,
)


class TestChecksum(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(sum_check(b''), 0)

    def test_single_byte(self):
        self.assertEqual(sum_check(b'\x01'), 1)

    def test_multiple_bytes(self):
        self.assertEqual(sum_check(b'\x01\x02\x03'), 6)

    def test_modulo_256(self):
        self.assertEqual(sum_check(b'\xFF\x01'), 0)


class TestClampSigned8(unittest.TestCase):
    def test_in_range(self):
        self.assertEqual(_clamp_signed8(0), 0)
        self.assertEqual(_clamp_signed8(64), 64)
        self.assertEqual(_clamp_signed8(-64), -64)

    def test_out_of_range(self):
        self.assertEqual(_clamp_signed8(128), 127)
        self.assertEqual(_clamp_signed8(-129), -128)
        self.assertEqual(_clamp_signed8(255), 127)
        self.assertEqual(_clamp_signed8(-255), -128)


class TestClampSpeed(unittest.TestCase):
    def test_in_range(self):
        self.assertEqual(_clamp_speed(0), 0)
        self.assertEqual(_clamp_speed(100), 100)
        self.assertEqual(_clamp_speed(-100), -100)

    def test_out_of_range(self):
        self.assertEqual(_clamp_speed(101), 100)
        self.assertEqual(_clamp_speed(-101), -100)
        self.assertEqual(_clamp_speed(127), 100)
        self.assertEqual(_clamp_speed(-128), -100)


class TestBuildPacket(unittest.TestCase):
    def test_minimal(self):
        pkt = build_packet(0, 0x01)
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[2], 6)  # length
        self.assertEqual(pkt[3], 0)  # order
        self.assertEqual(pkt[4], 0x01)  # action
        self.assertEqual(pkt[5], sum_check(pkt[:-1]))  # checksum

    def test_with_payload(self):
        pkt = build_packet(1, 0x11, b'\x01\x02')
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[2], 8)  # length
        self.assertEqual(pkt[3], 1)  # order
        self.assertEqual(pkt[4], 0x11)  # action
        self.assertEqual(pkt[5:7], b'\x01\x02')  # payload
        self.assertEqual(pkt[7], sum_check(pkt[:-1]))  # checksum


class TestParseFunctions(unittest.TestCase):
    def test_parse_header_valid(self):
        self.assertTrue(parse_header(b'RB\x00'))

    def test_parse_header_invalid(self):
        self.assertFalse(parse_header(b'AB\x00'))
        self.assertFalse(parse_header(b''))
        self.assertFalse(parse_header(b'R'))

    def test_parse_order_id(self):
        self.assertEqual(parse_order_id(b'RB\x06\x05\x01\x0D'), 5)

    def test_parse_action(self):
        self.assertEqual(parse_action(b'RB\x06\x05\x01\x0D'), 0x01)

    def test_parse_length(self):
        self.assertEqual(parse_length(b'RB\x06\x05\x01\x0D'), 6)

    def test_parse_checksum_ok(self):
        # Build a valid packet and verify checksum
        pkt = build_packet(0x05, 0x01)
        self.assertTrue(parse_checksum_ok(pkt))

    def test_parse_checksum_bad(self):
        # Build a valid packet and corrupt the checksum
        pkt = bytearray(build_packet(0x05, 0x01))
        pkt[-1] = (pkt[-1] + 1) % 256  # Corrupt checksum
        self.assertFalse(parse_checksum_ok(bytes(pkt)))


class TestExtractPackets(unittest.TestCase):
    def test_single_complete(self):
        pkt = build_packet(0, 0x01)
        packets, remaining = extract_packets(pkt)
        self.assertEqual(len(packets), 1)
        self.assertEqual(packets[0], pkt)
        self.assertEqual(remaining, b'')

    def test_multiple(self):
        pkt1 = build_packet(0, 0x01)
        pkt2 = build_packet(1, 0x02)
        packets, remaining = extract_packets(pkt1 + pkt2)
        self.assertEqual(len(packets), 2)
        self.assertEqual(remaining, b'')

    def test_incomplete(self):
        pkt = build_packet(0, 0x01)
        packets, remaining = extract_packets(pkt[:3])
        self.assertEqual(len(packets), 0)
        self.assertEqual(remaining, pkt[:3])

    def test_with_garbage(self):
        pkt = build_packet(0, 0x01)
        data = b'\x00\x00\x00' + pkt
        packets, remaining = extract_packets(data)
        self.assertEqual(len(packets), 1)
        self.assertEqual(packets[0], pkt)


class TestBuildSetLed(unittest.TestCase):
    def test_build(self):
        pkt = build_set_led(0, Port.BOARD_LED_1, 255, 0, 0)
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[4], Action.SET_LED)
        self.assertEqual(len(pkt), 10)

    def test_port_clamped(self):
        pkt = build_set_led(0, -4, 255, 0, 0)
        port_byte = pkt[5]
        self.assertEqual(port_byte, 0xFC)  # -4 as unsigned byte


class TestBuildSetMotor(unittest.TestCase):
    def test_build(self):
        pkt = build_set_motor(0, 1, 50)
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[4], Action.SET_MOTOR)
        self.assertEqual(len(pkt), 8)

    def test_speed_clamped(self):
        pkt = build_set_motor(0, 1, 150)
        speed_byte = pkt[6]
        self.assertEqual(speed_byte, 100)  # clamped to 100

    def test_negative_speed(self):
        pkt = build_set_motor(0, 1, -50)
        speed_byte = pkt[6]
        self.assertEqual(speed_byte, 0xCE)  # -50 as signed byte


class TestBuildSetMove(unittest.TestCase):
    def test_build(self):
        pkt = build_set_move(0, 50, -50)
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[4], Action.SET_MOTOR)
        self.assertEqual(len(pkt), 9)

    def test_port_is_zero(self):
        pkt = build_set_move(0, 50, 50)
        self.assertEqual(pkt[5], 0)  # port=0 for dual motor


class TestBuildSetBuzzer(unittest.TestCase):
    def test_build(self):
        pkt = build_set_buzzer(0, Port.BOARD_BUZZER, 440, 200)
        self.assertEqual(pkt[:2], b'RB')
        self.assertEqual(pkt[4], Action.SET_BUZZER)
        # header(2) + len(1) + order(1) + action(1) + port(1) + freq(2) + duration(2) + checksum(1) = 11
        self.assertEqual(len(pkt), 11)


class TestOrderManager(unittest.TestCase):
    def test_sequential(self):
        om = OrderManager()
        self.assertEqual(om.create(), 2)
        self.assertEqual(om.create(), 3)
        self.assertEqual(om.create(), 4)

    def test_wraps_around(self):
        om = OrderManager()
        om._next = 254
        self.assertEqual(om.create(), 254)
        self.assertEqual(om.create(), 2)


class TestParseResponses(unittest.TestCase):
    def _make_response(self, action, *data_bytes):
        """Helper to build a valid response packet with correct checksum.

        Response format: [RB 2B][length 1B][orderId 1B][action 1B][data N][checksum 1B]
        Note: Port is NOT included in the response.
        """
        data = bytearray([0x52, 0x42, 6 + len(data_bytes), 0x00, action])
        data.extend(data_bytes)
        checksum = sum(data) % 256
        data.append(checksum)
        return bytes(data)

    def test_parse_ultrasonic(self):
        # Ultrasonic: high=0x00, low=0x64 = 100mm
        pkt = self._make_response(0xA1, 0x00, 0x64)
        self.assertEqual(parse_ultrasonic(pkt), 100)

    def test_parse_voltage(self):
        # Voltage: 0x50 = 80%
        pkt = self._make_response(0xA3, 0x50)
        self.assertEqual(parse_voltage(pkt), 80)

    def test_parse_button(self):
        # Button: 0x01 = pressed
        pkt = self._make_response(0xA2, 0x01)
        self.assertEqual(parse_button(pkt), 1)

    def test_parse_light(self):
        # Light: high=0x01, low=0x00 = 256
        pkt = self._make_response(0xA6, 0x01, 0x00)
        self.assertEqual(parse_light(pkt), 256)

    def test_parse_temp_humidity(self):
        # Temp/humidity: hum_h=0x1E(30), hum_l=0x05(.5), temp_h=0x19(25), temp_l=0x03(.3)
        pkt = self._make_response(0xA5, 0x1E, 0x05, 0x19, 0x03)
        result = parse_temp_humidity(pkt)
        self.assertEqual(result['temperature'], 25.3)
        self.assertEqual(result['humidity'], 30.5)


if __name__ == '__main__':
    unittest.main()
