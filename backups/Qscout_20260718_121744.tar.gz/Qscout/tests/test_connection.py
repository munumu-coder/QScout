"""Unit tests for qscout.connection module."""

import unittest
from unittest.mock import Mock, patch, MagicMock
from qscout.connection import Connection


class TestConnectionInit(unittest.TestCase):
    def test_default_port(self):
        conn = Connection()
        self.assertEqual(conn._port_name, '/dev/ttyUSB0')
        self.assertEqual(conn._baudrate, 115200)
        self.assertEqual(conn._timeout, 0.5)

    def test_custom_port(self):
        conn = Connection(port='/dev/ttyUSB1', baudrate=9600, timeout=1.0)
        self.assertEqual(conn._port_name, '/dev/ttyUSB1')
        self.assertEqual(conn._baudrate, 9600)
        self.assertEqual(conn._timeout, 1.0)


class TestConnectionState(unittest.TestCase):
    def test_not_open_initially(self):
        conn = Connection()
        self.assertFalse(conn.is_open)

    @patch('qscout.connection.serial.Serial')
    def test_open(self, mock_serial):
        conn = Connection()
        conn.open()
        self.assertTrue(conn.is_open)
        mock_serial.assert_called_once()

    @patch('qscout.connection.serial.Serial')
    def test_close(self, mock_serial):
        conn = Connection()
        conn.open()
        conn.close()
        self.assertFalse(conn.is_open)

    def test_write_when_closed(self):
        conn = Connection()
        with self.assertRaises(ConnectionError):
            conn.write(b'test')

    def test_read_when_closed(self):
        conn = Connection()
        with self.assertRaises(ConnectionError):
            conn.read(1)


class TestReceive(unittest.TestCase):
    @patch('qscout.connection.serial.Serial')
    def test_receive_timeout(self, mock_serial):
        mock_serial_instance = Mock()
        mock_serial_instance.in_waiting = 0
        mock_serial.return_value = mock_serial_instance

        conn = Connection()
        conn.open()
        result = conn.receive(timeout=0.1)
        self.assertIsNone(result)

    @patch('qscout.connection.serial.Serial')
    def test_receive_packet(self, mock_serial):
        from qscout.protocol import build_packet
        pkt = build_packet(0, 0x01)

        mock_serial_instance = Mock()
        mock_serial_instance.in_waiting = len(pkt)
        mock_serial_instance.read.return_value = pkt
        mock_serial.return_value = mock_serial_instance

        conn = Connection()
        conn.open()
        result = conn.receive(timeout=0.1)
        self.assertEqual(result, pkt)


class TestFindQscout(unittest.TestCase):
    @patch('qscout.connection.serial.tools.list_ports.comports')
    def test_found(self, mock_comports):
        mock_port = Mock()
        mock_port.description = 'CH340 USB-Serial'
        mock_port.device = '/dev/ttyUSB0'
        mock_comports.return_value = [mock_port]

        result = Connection.find_qscout()
        self.assertEqual(result, '/dev/ttyUSB0')

    @patch('qscout.connection.serial.tools.list_ports.comports')
    def test_not_found(self, mock_comports):
        mock_port = Mock()
        mock_port.description = 'Other Device'
        mock_port.device = '/dev/ttyUSB0'
        mock_comports.return_value = [mock_port]

        result = Connection.find_qscout()
        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()
