#!/usr/bin/env python3
"""
Validación de hardware del Q-Scout.
Prueba LEDs, buzzer y motores.
Envía stop() automáticamente si el script termina por error.
"""

import sys
import time
import atexit

sys.path.insert(0, '/media/munumu/42529c62-b253-4db5-b8d3-bea4b7cf5e37/Documents/Default Project')
from qscout import QScout


class HWValidator:
    def __init__(self):
        self.robot = None
        self.passed = 0
        self.failed = 0
        self._last_action = None

    def _safe_stop(self):
        """Envía stop() si hay conexión. Se ejecuta al salir."""
        if self.robot and self.robot._serial:
            try:
                self.robot.stop()
                print("\n[SEGURIDAD] Motores detenidos.")
            except Exception:
                pass

    def log(self, label, sent_hex, resp_hex, ok):
        status = "OK" if ok else "ERROR"
        print(f"  Paquete enviado:  {sent_hex}")
        print(f"  Respuesta:        {resp_hex or 'NINGUNA'}")
        print(f"  Resultado:        [{status}] {label}")
        if ok:
            self.passed += 1
        else:
            self.failed += 1

    def test_info(self):
        print("\n--- A) INFORMACION ---")
        self._last_action = "get_device_info"
        info = self.robot.get_device_info()
        if info:
            print(f"  Firmware: v{info.firmware}")
            print(f"  Hardware: {info.hw_version}")
            self.log("Device info", "0x01", f"v{info.firmware} HW{info.hw_version}", True)
        else:
            self.log("Device info", "0x01", "NINGUNA", False)

    def test_led(self, port, name, r, g, b, duration=3):
        print(f"\n--- LED {name} RGB({r},{g},{b}) ---")

        self._last_action = f"set_led {name} ON"
        self.robot.set_led(port, r, g, b)
        print(f"  Encendido {duration}s...")
        time.sleep(duration)

        self._last_action = f"set_led {name} OFF"
        ok = self.robot.set_led(port, 0, 0, 0)
        self.log(f"LED {name} apagado", "set_led OFF", "ACK" if ok else "NINGUNA", ok)

    def test_buzzer(self):
        print("\n--- BUZZER ---")
        self._last_action = "set_buzzer ON"
        ok = self.robot.set_buzzer(QScout.BUZZER, 1000, duration_ms=1000)
        print("  Sonido 1000Hz durante 1s...")
        time.sleep(1.5)

        self._last_action = "set_buzzer OFF"
        ok2 = self.robot.set_buzzer(QScout.BUZZER, 0, 0)
        self.log("Buzzer parado", "set_buzzer 0Hz", "OK (fire-and-forget)", ok)

    def test_motors(self):
        print("\n--- MOTORES ---")

        self._last_action = "stop inicial"
        self.robot.stop()
        print("  Stop inicial enviado.")

        self._last_action = "set_motor M1+M2"
        ok1 = self.robot.set_motor(QScout.M1, 30)
        ok2 = self.robot.set_motor(QScout.M2, 30)
        print("  Motores adelante velocidad 30, 2s...")
        time.sleep(2)

        self._last_action = "stop final"
        ok_stop = self.robot.stop()
        self.log("Motores test", "set_motor 30 + stop", f"M1={'OK' if ok1 else 'ERR'} M2={'OK' if ok2 else 'ERR'} Stop={'OK' if ok_stop else 'ERR'}", ok1 and ok2 and ok_stop)

    def run(self):
        atexit.register(self._safe_stop)

        print("=" * 50)
        print("  VALIDACION DE HARDWARE Q-SCOUT")
        print("=" * 50)

        try:
            self.robot = QScout()
            info = self.robot.connect()
            print(f"\nConectado: Firmware v{info.firmware}, HW {info.hw_version}")
        except Exception as e:
            print(f"\n[ERROR] No se pudo conectar: {e}")
            return

        try:
            self.test_info()
            self.test_led(QScout.LED1, "LED1", 255, 0, 0, 3)
            self.test_led(QScout.LED2, "LED2", 0, 255, 0, 3)
            self.test_buzzer()
            self.test_motors()
        except Exception as e:
            print(f"\n[ERROR FATAL] {e}")
            print("  El mecanismo de seguridad enviará stop() al salir.")
        finally:
            if self.robot:
                self.robot.disconnect()

        print("\n" + "=" * 50)
        print(f"  RESULTADO: {self.passed} OK / {self.failed} ERRORES")
        print("=" * 50)


if __name__ == '__main__':
    validator = HWValidator()
    validator.run()
