#!/usr/bin/env python3
"""
Test independiente de motores Q-Scout.
Logging completo: timestamp, paquete HEX, ACK, respuesta ESP32.
Usa setMove (9 bytes) para stop de ambos motores.
"""

import sys
import time
from datetime import datetime

sys.path.insert(0, '/media/munumu/42529c62-b253-4db5-b8d3-bea4b7cf5e37/Documents/Default Project')
from qscout import QScout


def ts():
    return datetime.now().strftime('%H:%M:%S.%f')[:-3]


def log(msg):
    print(f"[{ts()}] {msg}")


def build_set_motor(order, port, speed):
    """Protocol.setMotor: 8 bytes, controla UN motor."""
    size = 8
    header = b'RB' + bytes([size, order, 0x11])
    packet = header + bytes([port & 0xFF, speed & 0xFF])
    checksum = sum(packet) % 256
    return packet + bytes([checksum])


def build_set_move(order, m1_speed, m2_speed):
    """Protocol.setMove: 9 bytes, controla AMBOS motores."""
    size = 9
    header = b'RB' + bytes([size, order, 0x11])
    packet = header + bytes([0x00, m1_speed & 0xFF, m2_speed & 0xFF])
    checksum = sum(packet) % 256
    return packet + bytes([checksum])


def send_and_log(robot, label, packet):
    """Envía paquete y muestra toda la info."""
    log(f"ENVIANDO {label}")
    log(f"  HEX: {packet.hex()}")
    log(f"  Bytes: {' '.join(f'{b:02X}' for b in packet)}")

    robot._drain(0.05)
    robot._send_raw(pkt := packet)
    r = robot._wait_response(timeout=2.0)

    if r:
        log(f"  RESPUESTA: {r.hex()}")
        log(f"  Size={r[2]}, Order={r[3]}, Data={list(r[4:-1])}, Checksum=0x{r[-1]:02X}")
        ok = len(r) >= 6 and r[4] == 1
        log(f"  RESULTADO: {'OK (ACK)' if ok else f'ERROR (result={r[4]})'}")
        return ok
    else:
        log(f"  RESPUESTA: NINGUNA")
        log(f"  RESULTADO: TIMEOUT")
        return False


def drain_all(robot, duration=2.0):
    """Lee todo lo que queda en el buffer."""
    end = time.time() + duration
    data = b''
    while time.time() < end:
        chunk = robot._serial.read(200)
        if chunk:
            data += chunk
    return data


def main():
    log("=" * 60)
    log("TEST INDEPENDIENTE DE MOTORES Q-SCOUT")
    log("=" * 60)

    robot = QScout()

    try:
        info = robot.connect()
        log(f"Conectado: Firmware v{info.firmware}, HW {info.hw_version}")
    except Exception as e:
        log(f"[ERROR] No se pudo conectar: {e}")
        return

    try:
        # === FASE 1: STOP con setMove(0,0,0) ===
        log("\n" + "=" * 60)
        log("FASE 1: STOP con setMove(0, 0, 0) - paquete 9 bytes")
        log("=" * 60)

        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        send_and_log(robot, "setMove(M1=0, M2=0)", pkt)

        log("\nEsperando 2 segundos después del stop...")
        time.sleep(2)

        data = drain_all(robot, 1.0)
        if data:
            log(f"  Datos pendientes: {data.hex()}")

        # === FASE 2: MOVER ambos motores speed=30 ===
        log("\n" + "=" * 60)
        log("FASE 2: MOVER M1=30, M2=30 con setMove - paquete 9 bytes")
        log("=" * 60)

        order = robot._next_order()
        pkt = build_set_move(order, 30, 30)
        send_and_log(robot, "setMove(M1=30, M2=30)", pkt)

        log("Motores moviendo... 2 segundos")
        time.sleep(2)

        # === FASE 3: STOP con setMove(0,0,0) ===
        log("\n" + "=" * 60)
        log("FASE 3: STOP con setMove(0, 0, 0) - paquete 9 bytes")
        log("=" * 60)

        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        ok = send_and_log(robot, "setMove(M1=0, M2=0)", pkt)

        if not ok:
            log("  [REINTENTO] Enviando stop de nuevo...")
            order = robot._next_order()
            pkt = build_set_move(order, 0, 0)
            send_and_log(robot, "setMove(M1=0, M2=0) [reintento]", pkt)

        # === FASE 4: Verificar limpieza ===
        log("\n" + "=" * 60)
        log("FASE 4: Esperando 5 segundos y leyendo respuestas pendientes")
        log("=" * 60)

        time.sleep(5)
        data = drain_all(robot, 2.0)
        if data:
            log(f"  Datos pendientes después de 5s: {data.hex()}")
            # Buscar paquetes RB en los datos
            i = 0
            while i < len(data) - 4:
                if data[i] == 0x52 and data[i+1] == 0x42:
                    size = data[i+2]
                    if 5 <= size <= 20 and i + size <= len(data):
                        pkt = data[i:i+size]
                        cs = sum(pkt[:-1]) % 256
                        if cs == pkt[-1]:
                            log(f"  RB encontrado: {pkt.hex()}")
                            i += size
                            continue
                i += 1
        else:
            log("  Sin datos pendientes - motor limpio")

        # === FASE 5: Comparar con setMotor (método antiguo) ===
        log("\n" + "=" * 60)
        log("FASE 5: Comparar con setMotor (8 bytes, método antiguo)")
        log("=" * 60)

        log("\n5a: STOP con setMotor(M1, 0) - paquete 8 bytes")
        order = robot._next_order()
        pkt = build_set_motor(order, 0xFF, 0)
        send_and_log(robot, "setMotor(M1=0)", pkt)

        log("\n5b: STOP con setMotor(M2, 0) - paquete 8 bytes")
        order = robot._next_order()
        pkt = build_set_motor(order, 0xFE, 0)
        send_and_log(robot, "setMotor(M2=0)", pkt)

        log("\n5c: MOVER con setMotor M1=30")
        order = robot._next_order()
        pkt = build_set_motor(order, 0xFF, 30)
        send_and_log(robot, "setMotor(M1=30)", pkt)

        log("Motores moviendo... 2 segundos")
        time.sleep(2)

        log("\n5d: STOP con setMotor(M1, 0) - paquete 8 bytes")
        order = robot._next_order()
        pkt = build_set_motor(order, 0xFF, 0)
        send_and_log(robot, "setMotor(M1=0)", pkt)

        log("\n5e: STOP con setMotor(M2, 0) - paquete 8 bytes")
        order = robot._next_order()
        pkt = build_set_motor(order, 0xFE, 0)
        send_and_log(robot, "setMotor(M2=0)", pkt)

        log("\nEsperando 5 segundos...")
        time.sleep(5)
        data = drain_all(robot, 2.0)
        if data:
            log(f"  Datos pendientes después de setMotor stop: {data.hex()}")
        else:
            log("  Sin datos pendientes")

    except KeyboardInterrupt:
        log("\n[INTERRUPCION] Enviando stop de emergencia...")
        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        robot._send_raw(pkt)
        log("Stop de emergencia enviado.")
    except Exception as e:
        log(f"\n[ERROR] {e}")
        log("Enviando stop de emergencia...")
        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        robot._send_raw(pkt)
    finally:
        robot.disconnect()

    log("\n" + "=" * 60)
    log("TEST COMPLETADO")
    log("=" * 60)


if __name__ == '__main__':
    main()
