#!/usr/bin/env python3
"""
Q-Scout Protocol Test Script
Tests all known UART protocol commands on the Robobloq Q-Scout.
"""

import serial
import time
import sys

class QScoutProtocol:
    PORT_M1 = 0xFF
    PORT_M2 = 0xFE
    PORT_POWER = 0xFD
    PORT_LED1 = 0xFC
    PORT_LED2 = 0xFB
    PORT_BUZZER = 0xFA
    PORT_BUTTON = 0xF9
    PORT_IF1 = 0x01
    PORT_IF2 = 0x02
    PORT_IF3 = 0x03
    PORT_IF4 = 0x04
    PORT_IF5 = 0x05
    PORT_IF6 = 0x06
    PORT_IF7 = 0x07
    PORT_IF8 = 0x08

    ACTION_GET_DEVICE_INFO = 0x01
    ACTION_GET_INTERFACE_INFO = 0x02
    ACTION_GET_ALL_INTERFACE_INFO = 0x03
    ACTION_GET_MOTOR_INTERFACE_INFO = 0x04
    ACTION_GET_USER_INTERFACE_INFO = 0x05
    ACTION_SET_LED = 0x10
    ACTION_SET_MOTOR = 0x11
    ACTION_SET_ULTRASONIC_LIGHT = 0x12
    ACTION_SET_BUZZER = 0x13
    ACTION_SET_MATRIX = 0x14
    ACTION_LOW_BATTERY = 0x15
    ACTION_CLICK_BUTTON = 0x16
    ACTION_SET_WORK_MODE = 0x18
    ACTION_SET_STEERING_ENGINE = 0x19
    ACTION_SET_OUT_ENGINE = 0x1A
    ACTION_SET_HARDWARE_UPDATE = 0x21
    ACTION_GET_ULTRASONIC = 0xA1
    ACTION_GET_BUTTON_INFO = 0xA2
    ACTION_GET_VOLTAGE = 0xA3
    ACTION_GET_LINE_VALUE = 0xA4
    ACTION_GET_TEMPERATURE_HUMIDITY = 0xA5
    ACTION_GET_LIGHT_SENSOR = 0xA6
    ACTION_GET_VOICE_SENSOR = 0xA7
    ACTION_GET_INFRARED = 0xA8
    ACTION_GET_GYRO = 0xA9
    ACTION_GET_COLOR_SENSOR = 0xAA
    ACTION_GET_TOUCH_BUTTON = 0xAB
    ACTION_GET_TWO_TEMPERATURE = 0xAC
    ACTION_GET_SIX_LINE_VALUE = 0xAD
    ACTION_GET_ROCKER = 0xAE
    ACTION_GET_FLAME_SENSOR = 0xAF
    ACTION_GET_GAS_SENSOR = 0xB0
    ACTION_GET_SPIRAL_POTENTIOMETER = 0xB1
    ACTION_GET_LINE_POTENTIOMETER = 0xB2
    ACTION_GET_EXT_IO_INPUT = 0xB4
    ACTION_GET_EXT_APC = 0xB5
    ACTION_GET_EXT_TEMP_HUMI = 0xB6

    def __init__(self, port='/dev/ttyUSB0', baudrate=115200):
        self.ser = serial.Serial(port, baudrate, timeout=0.01)
        self._order = 0

    def close(self):
        self.ser.close()

    def _next_order(self):
        self._order = (self._order + 1) & 0xFF
        if self._order == 0:
            self._order = 1
        return self._order

    @staticmethod
    def _checksum(data):
        return sum(data) % 256

    def build_packet(self, order, action, data=bytes()):
        size = 6 + len(data)
        header = b'RB' + bytes([size, order, action])
        packet = header + data
        packet += bytes([self._checksum(packet)])
        return packet

    def send(self, order, action, data=bytes()):
        packet = self.build_packet(order, action, data)
        self.ser.write(packet)
        self.ser.flush()

    def wait_response(self, timeout=2.0):
        rb_buf = bytearray()
        start = time.time()
        while time.time() - start < timeout:
            b = self.ser.read(1)
            if not b:
                if rb_buf and len(rb_buf) >= 5 and rb_buf[0] == 0x52 and rb_buf[1] == 0x42:
                    cs = sum(rb_buf[:-1]) % 256
                    if cs == rb_buf[-1]:
                        return bytes(rb_buf)
                rb_buf = bytearray()
                continue
            byte_val = b[0]
            if byte_val == 0x52:
                rb_buf = bytearray(b)
            elif byte_val == 0x42 and len(rb_buf) == 1:
                rb_buf.append(byte_val)
            elif len(rb_buf) >= 2:
                rb_buf.append(byte_val)
                if len(rb_buf) >= 3:
                    expected = rb_buf[2]
                    if expected < 5 or expected > 30:
                        rb_buf = bytearray()
                    elif len(rb_buf) == expected:
                        cs = sum(rb_buf[:-1]) % 256
                        if cs == rb_buf[-1]:
                            return bytes(rb_buf)
                        rb_buf = bytearray()
        return None

    def drain(self, duration=0.3):
        end = time.time() + duration
        while time.time() < end:
            self.ser.read(500)

    def send_and_wait(self, action, data=bytes(), timeout=2.0):
        order = self._next_order()
        self.send(order, action, data)
        return self.wait_response(timeout)

    def send_no_wait(self, action, data=bytes()):
        order = self._next_order()
        self.send(order, action, data)
        return order

    # --- Query Commands ---

    def get_device_info(self):
        r = self.send_and_wait(self.ACTION_GET_DEVICE_INFO)
        if r and len(r) >= 8:
            return {
                'fw_major': r[4],
                'fw_minor': r[5],
                'fw_patch': r[6],
                'hw_version': r[7],
                'raw': r.hex()
            }
        return None

    def get_interface_info(self, port):
        r = self.send_and_wait(self.ACTION_GET_INTERFACE_INFO, bytes([port & 0xFF]))
        if r and len(r) >= 5:
            if len(r) >= 6:
                return {'device_type': r[4], 'raw': r.hex()}
            return {'device_type': None, 'raw': r.hex()}
        return None

    def get_all_interface_info(self):
        r = self.send_and_wait(self.ACTION_GET_ALL_INTERFACE_INFO, timeout=5.0)
        if r and len(r) >= 15:
            devices = list(r[4:14])
            return {'devices': devices, 'raw': r.hex()}
        return None

    def get_motor_interface_info(self):
        r = self.send_and_wait(self.ACTION_GET_MOTOR_INTERFACE_INFO)
        if r and len(r) >= 7:
            return {'data': list(r[4:6]), 'raw': r.hex()}
        return None

    def get_voltage(self, port):
        r = self.send_and_wait(self.ACTION_GET_VOLTAGE, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return {'voltage': r[5], 'raw': r.hex()}
        return None

    # --- Set Commands ---

    def set_motor(self, port, speed):
        speed = max(-100, min(100, speed))
        r = self.send_and_wait(self.ACTION_SET_MOTOR, bytes([port & 0xFF, speed & 0xFF]))
        if r and len(r) >= 6:
            return {'result': r[4], 'raw': r.hex()}
        return None

    def stop_motors(self):
        r1 = self.set_motor(self.PORT_M1, 0)
        r2 = self.set_motor(self.PORT_M2, 0)
        return r1, r2

    def set_click_button(self, port, enable):
        r = self.send_and_wait(self.ACTION_CLICK_BUTTON, bytes([port & 0xFF, int(enable)]))
        if r and len(r) >= 6:
            return {'result': r[4], 'raw': r.hex()}
        return None

    def set_low_battery(self, port, enable):
        r = self.send_and_wait(self.ACTION_LOW_BATTERY, bytes([port & 0xFF, int(enable)]))
        if r and len(r) >= 6:
            return {'result': r[4], 'raw': r.hex()}
        return None


def run_tests(ser_port='/dev/ttyUSB0'):
    proto = QScoutProtocol(ser_port)

    print("=" * 60)
    print("Q-Scout Protocol Test")
    print("=" * 60)

    proto.drain(1.0)

    print("\n[1] get_device_info (0x01)")
    info = proto.get_device_info()
    if info:
        print(f"  Firmware: v{info['fw_major']}.{info['fw_minor']}.{info['fw_patch']}")
        print(f"  Hardware: {info['hw_version']}")
        print(f"  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE")

    print("\n[2] get_interface_info (0x02) - All ports")
    ports = [
        (proto.PORT_M1, "M1"),
        (proto.PORT_M2, "M2"),
        (proto.PORT_POWER, "Power"),
        (proto.PORT_LED1, "LED1"),
        (proto.PORT_LED2, "LED2"),
        (proto.PORT_BUZZER, "Buzzer"),
        (proto.PORT_BUTTON, "Button"),
        (proto.PORT_IF1, "Interface1"),
        (proto.PORT_IF2, "Interface2"),
        (proto.PORT_IF3, "Interface3"),
        (proto.PORT_IF4, "Interface4"),
        (proto.PORT_IF5, "Interface5"),
        (proto.PORT_IF6, "Interface6"),
        (proto.PORT_IF7, "Interface7"),
        (proto.PORT_IF8, "Interface8"),
    ]
    for port_val, name in ports:
        info = proto.get_interface_info(port_val)
        if info:
            dt = info.get('device_type')
            print(f"  {name:12s} (0x{port_val & 0xFF:02X}): device_type={dt}  raw={info['raw']}")
        else:
            print(f"  {name:12s} (0x{port_val & 0xFF:02X}): NO RESPONSE")

    print("\n[3] get_motor_interface_info (0x04)")
    info = proto.get_motor_interface_info()
    if info:
        print(f"  Data: {info['data']}  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE")

    print("\n[4] get_all_interface_info (0x03)")
    info = proto.get_all_interface_info()
    if info:
        print(f"  Devices: {info['devices']}  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE (firmware limitation)")

    print("\n[5] get_voltage (0xA3)")
    for port_val, name in [(proto.PORT_POWER, "Power"), (proto.PORT_IF1, "Interface1")]:
        info = proto.get_voltage(port_val)
        if info:
            print(f"  {name}: voltage={info['voltage']}  Raw: {info['raw']}")
        else:
            print(f"  {name}: NO RESPONSE (firmware limitation)")

    print("\n[6] set_click_button (0x16)")
    info = proto.set_click_button(proto.PORT_BUTTON, True)
    if info:
        print(f"  Enable button notification: result={info['result']}  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE")

    print("\n[7] set_low_battery (0x15)")
    info = proto.set_low_battery(proto.PORT_POWER, True)
    if info:
        print(f"  Enable low battery: result={info['result']}  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE")

    print("\n[8] set_motor (0x11) - Motor test")
    print("  Running M1 forward speed 30 for 1 second...")
    info = proto.set_motor(proto.PORT_M1, 30)
    if info:
        print(f"  M1 start: result={info['result']}  Raw: {info['raw']}")
    else:
        print("  NO RESPONSE")

    time.sleep(1.0)

    print("  Stopping motors...")
    r1, r2 = proto.stop_motors()
    if r1:
        print(f"  M1 stop: result={r1['result']}")
    if r2:
        print(f"  M2 stop: result={r2['result']}")

    proto.drain(0.5)

    print("\n" + "=" * 60)
    print("Test Complete")
    print("=" * 60)

    proto.close()


if __name__ == '__main__':
    port = sys.argv[1] if len(sys.argv) > 1 else '/dev/ttyUSB0'
    run_tests(port)
