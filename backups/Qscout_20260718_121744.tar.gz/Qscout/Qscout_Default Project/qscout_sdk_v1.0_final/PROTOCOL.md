# Q-Scout UART Protocol Documentation

**Device:** Robobloq Q-Scout (RB-00002)
**Firmware:** v3.0.1 (esp32spiram-20210902-v1.17)
**Connection:** USB-Serial CH340, 115200 baud, 8N1

## Packet Format

### Request (Host → ESP32)

| Offset | Field     | Size  | Description                        |
|--------|-----------|-------|------------------------------------|
| 0      | Header    | 2B    | `0x52 0x42` ("RB")                 |
| 2      | Size      | 1B    | Total packet length (including header) |
| 3      | Order     | 1B    | Sequence number (0-255, wraps)     |
| 4      | Action    | 1B    | Command code (see actions table)   |
| 5+     | Data      | 0-NB  | Command-specific payload           |
| last   | Checksum  | 1B    | `sum(all bytes except checksum) % 256` |

### Response (ESP32 → Host)

| Offset | Field     | Size  | Description                        |
|--------|-----------|-------|------------------------------------|
| 0      | Header    | 2B    | `0x52 0x42` ("RB")                 |
| 2      | Size      | 1B    | Total packet length                |
| 3      | Order     | 1B    | Echoed request order number        |
| 4+     | Data      | 0-NB  | Response-specific payload          |
| last   | Checksum  | 1B    | `sum(all bytes except checksum) % 256` |

## Port Constants

| Name            | Value | Hex   | Description                    |
|-----------------|-------|-------|--------------------------------|
| board_motor_m1  | -1    | 0xFF  | Onboard motor M1               |
| board_motor_m2  | -2    | 0xFE  | Onboard motor M2               |
| board_power     | -3    | 0xFD  | Onboard power/battery          |
| board_led_1     | -4    | 0xFC  | Onboard LED 1                  |
| board_led_2     | -5    | 0xFB  | Onboard LED 2                  |
| board_buzzer    | -6    | 0xFA  | Onboard buzzer                 |
| board_button    | -7    | 0xF9  | Onboard button                 |
| interface1      | 1     | 0x01  | User port 1 (motor/servo)      |
| interface2      | 2     | 0x02  | User port 2 (sensors)          |
| interface3      | 3     | 0x03  | User port 3 (sensors)          |
| interface4      | 4     | 0x04  | User port 4 (sensors)          |
| interface5      | 5     | 0x05  | User port 5 (sensors)          |
| interface6      | 6     | 0x06  | User port 6 (sensors)          |
| interface7      | 7     | 0x07  | User port 7 (sensors)          |
| interface8      | 8     | 0x08  | User port 8 (sensors)          |

## Action Codes

### Query Commands

| Action                    | Code   | Size | Data      | Response                | Status      |
|---------------------------|--------|------|-----------|-------------------------|-------------|
| get_device_info           | 0x01   | 6    | None      | fw_major, fw_minor, fw_patch, hw_ver | **WORKS** |
| get_interface_info        | 0x02   | 7    | port (1B) | device_type (1B) or ACK | **WORKS** |
| get_all_interface_info    | 0x03   | 6    | None      | 10 device types         | **NO RESPONSE** |
| get_motor_interface_info  | 0x04   | 6    | None      | motor_count, motor_type | **WORKS** |
| get_user_interface_info   | 0x05   | 6    | None      | ?                       | UNTESTED    |
| get_voltage               | 0xA3   | 7    | port (1B) | voltage (1B)            | **NO RESPONSE** |
| get_ultrasonic_value      | 0xA1   | 7    | port (1B) | distance (2B)           | UNTESTED    |
| get_button_info           | 0xA2   | 7    | port (1B) | button_state (1B)       | UNTESTED    |
| get_ltemperature_humidity | 0xA5   | 7    | port (1B) | temp, humidity          | UNTESTED    |
| get_light_sensor_value    | 0xA6   | 7    | port (1B) | light_value (2B)        | UNTESTED    |
| get_voice_sensor_value    | 0xA7   | 7    | port (1B) | voice_value             | UNTESTED    |
| get_infrared_value        | 0xA8   | 7    | port (1B) | infrared_value          | UNTESTED    |
| get_gyro_sensor_value     | 0xA9   | 7    | port (1B) | gyro_data               | UNTESTED    |
| get_color_sensor_value    | 0xAA   | 7    | port (1B) | color_data              | UNTESTED    |
| get_touch_button          | 0xAB   | 7    | port (1B) | touch_state             | UNTESTED    |

### Set Commands

| Action                    | Code   | Size | Data                  | ACK | Status    |
|---------------------------|--------|------|-----------------------|-----|-----------|
| set_led                   | 0x10   | 8    | port, r, g, b         | Yes | WORKS*    |
| set_motor                 | 0x11   | 8    | port, speed(-100..100)| Yes | **WORKS** |
| set_ultrasonic_light      | 0x12   | 8    | port, r, g, b         | Yes | UNTESTED  |
| set_buzzer                | 0x13   | 7    | port, freq(2B)        | Yes | UNTESTED  |
| set_matrix                | 0x14   | 12+  | port, pattern...      | Yes | UNTESTED  |
| low_battery               | 0x15   | 8    | port, flag(0/1)       | Yes | **WORKS** |
| click_button              | 0x16   | 8    | port, flag(0/1)       | Yes | **WORKS** |
| set_work_mode             | 0x18   | 8    | port, mode, value     | Yes | UNTESTED  |
| set_Steering_engine       | 0x19   | 8    | port, angle           | Yes | UNTESTED  |
| set_Out_engine            | 0x1A   | 8    | port, speed           | Yes | UNTESTED  |
| set_hardware_update       | 0x21   | 6    | None                  | Yes | UNTESTED  |

## Confirmed Responses

### get_device_info (0x01)
```
Request:  52 42 06 01 01 A1
Response: 52 42 08 01 03 00 01 A1
                     |  |  |  |  +-- checksum
                     |  |  |  +-- hardware version (1)
                     |  |  +-- firmware patch (0)
                     |  +-- firmware minor (3)
                     +-- firmware major (3)
```
Parsed: Firmware v3.0.1, Hardware v161 (0xA1)

### get_interface_info (0x02) - Board ports (no device)
```
Request:  52 42 07 0B 02 FF A4    (port M1 = 0xFF)
Response: 52 42 05 0B A4          (ACK only, no data byte)
```

### get_interface_info (0x02) - User ports (with device)
```
Request:  52 42 07 02 02 01 A0    (Interface1 = 0x01)
Response: 52 42 06 02 04 03       (device_type=4, ?)
```

### get_motor_interface_info (0x04)
```
Request:  52 42 06 05 04 A2
Response: 52 42 07 05 01 01 A2
                     |  |  +-- motor type?
                     |  +-- motor count (1)
                     +-- ?
```

### set_motor (0x11) - Speed control
```
Request:  52 42 08 01 11 FF 00 AD    (M1, speed=0)
Response: 52 42 06 01 01 9C          (ACK, result=1=success)

Request:  52 42 08 01 11 FF 20 CD    (M1, speed=32)
Response: 52 42 06 01 01 9C          (ACK, result=1=success)
```

### setClickButton (0x16)
```
Request:  52 42 08 32 16 F9 01 CD    (board_button, enable)
Response: 52 42 06 32 01 CD          (ACK, result=1)
```

### setLowBattery (0x15)
```
Request:  52 42 08 5A 15 FD 01 F5    (board_power, enable)
Response: 52 42 06 5A 01 F5          (ACK, result=1)
```

## Commands with No Response

The following commands send correctly but produce **zero bytes** of response from firmware v3.0.1:
- `get_all_interface_info` (0x03) - Expected 15-byte response with all port device types
- `get_voltage` (0xA3) - Expected 6-byte response with battery voltage

These commands are ACK'd by the firmware's command parser but the response data is never sent. This appears to be a firmware limitation in v3.0.1.

## Initialization Sequence (from MyQode source)

After connection, MyQode waits 3800ms then sends:
1. `setClickButton(board_button, 1)` - Enable button press notification
2. Registers data listener callback

Commands commented out in source:
- `setLowBatteryBack(board_power, 1)` - Low battery notification
- `startNotificationIntervalEvent()` - Periodic notification polling
