#!/usr/bin/env python3
"""
Ejemplos de movimiento básico para Q-Scout.

Prerequisitos:
    pip install pyserial
    Robot conectado vía USB
"""

import time
from qscout import QScout


def demo_basico():
    """Movimientos básicos con pausas."""
    print("=== Demo básico: Movimiento ===\n")

    with QScout() as robot:
        info = robot.get_device_info()
        print(f"Conectado: Q-Scout v{info.firmware}\n")

        # Avanzar 2 segundos
        print("→ Avanzar")
        robot.forward(50)
        time.sleep(2)

        # Parar 1 segundo
        print("  Parar")
        robot.stop()
        time.sleep(1)

        # Retroceder 2 segundos
        print("← Retroceder")
        robot.backward(50)
        time.sleep(2)

        # Parar 1 segundo
        print("  Parar")
        robot.stop()
        time.sleep(1)

        # Girar izquierda 1.5 segundos
        print("↙ Girar izquierda")
        robot.turn_left(50)
        time.sleep(1.5)

        # Parar 1 segundo
        print("  Parar")
        robot.stop()
        time.sleep(1)

        # Girar derecha 1.5 segundos
        print("↘ Girar derecha")
        robot.turn_right(50)
        time.sleep(1.5)

        # Parar final
        print("  Parar")
        robot.stop()

    print("\n=== Fin ===")


def demo_control_directo():
    """Control directo con set_move."""
    print("=== Demo: Control directo con set_move ===\n")

    with QScout() as robot:
        info = robot.get_device_info()
        print(f"Conectado: Q-Scout v{info.firmware}\n")

        # M1 adelante, M2 atrás (giro rápido)
        print("set_move(+80, -80) → Giro rápido")
        robot.set_move(80, -80)
        time.sleep(1)

        robot.stop()
        time.sleep(0.5)

        # M1 atrás, M2 adelante (giro rápido contrario)
        print("set_move(-80, +80) → Giro rápido contrario")
        robot.set_move(-80, 80)
        time.sleep(1)

        robot.stop()
        time.sleep(0.5)

        # M1 lento, M2 rápido (curva suave)
        print("set_move(30, 60) → Curva suave")
        robot.set_move(30, 60)
        time.sleep(2)

        robot.stop()

    print("\n=== Fin ===")


def demo_velocidades():
    """Probar diferentes velocidades."""
    print("=== Demo: Velocidades ===\n")

    with QScout() as robot:
        info = robot.get_device_info()
        print(f"Conectado: Q-Scout v{info.firmware}\n")

        for speed in [25, 50, 75, 100]:
            print(f"Velocidad: {speed}%")
            robot.forward(speed)
            time.sleep(1.5)
            robot.stop()
            time.sleep(0.5)

    print("\n=== Fin ===")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        demo = sys.argv[1]
        if demo == "directo":
            demo_control_directo()
        elif demo == "velocidades":
            demo_velocidades()
        else:
            print(f"Uso: {sys.argv[0]} [directo|velocidades]")
    else:
        demo_basico()