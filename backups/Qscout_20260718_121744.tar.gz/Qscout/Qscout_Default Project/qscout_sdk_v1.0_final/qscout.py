#!/usr/bin/env python3
"""
Q-Scout Python SDK v1.0
=======================

SDK para controlar el robot Robobloq Q-Scout via UART.

Protocolo experimental confirmado:
    - setMove (9 bytes): RB 09 order 0x11 0x00 m1Speed m2Speed CS
    - setMotor (8 bytes): RB 08 order 0x11 port speed CS

El firmware distingue ambos paquetes por el campo SIZE (byte[2]):
    - SIZE=9 → setMove: controla ambos motores
    - SIZE=8 → setMotor: controla un motor individual

Uso básico:
    from qscout import QScout

    with QScout() as robot:
        robot.forward(50)
        time.sleep(2)
        robot.stop()
"""

__version__ = "1.0.0"

import serial
import time
import threading
from enum import IntEnum
from dataclasses import dataclass
from typing import Optional, List


# =============================================================================
# CONSTANTES
# =============================================================================

class Port(IntEnum):
    """Identificadores de puerto del Q-Scout."""
    M1 = 0xFF
    M2 = 0xFE
    POWER = 0xFD
    LED1 = 0xFC
    LED2 = 0xFB
    BUZZER = 0xFA
    BUTTON = 0xF9
    IF1 = 1
    IF2 = 2
    IF3 = 3
    IF4 = 4
    IF5 = 5
    IF6 = 6
    IF7 = 7
    IF8 = 8


@dataclass
class DeviceInfo:
    """Información del dispositivo."""
    fw_major: int
    fw_minor: int
    fw_patch: int
    hw_version: int

    @property
    def firmware(self) -> str:
        return f"{self.fw_major}.{self.fw_minor}.{self.fw_patch}"


@dataclass
class InterfaceInfo:
    """Información de un puerto de interfaz."""
    port: int
    device_type: Optional[int]


# =============================================================================
# EXCEPCIONES
# =============================================================================

class QScoutError(Exception):
    """Error base del SDK."""
    pass


class QScoutTimeout(QScoutError):
    """Timeout esperando respuesta del robot."""
    pass


# =============================================================================
# SDK PRINCIPAL
# =============================================================================

class QScout:
    """
    SDK para controlar el robot Robobloq Q-Scout.

    API pública de movimiento (alta nivel):
        forward(speed)    → Avanzar
        backward(speed)   → Retroceder
        turn_left(speed)  → Girar izquierda (diferencial)
        turn_right(speed) → Girar derecha (diferencial)
        spin_left(speed)  → Giro sobre su eje izquierda
        spin_right(speed) → Giro sobre su eje derecha
        stop()            → Parar

    API pública de bajo nivel:
        set_move(m1_speed, m2_speed)  → Control directo motores
        set_motor(port, speed)        → Control individual motor
        send_raw(hex_str)             → Enviar paquete raw

    API de periféricos:
        set_led(port, r, g, b)  → Encender LED RGB
        set_buzzer(port, freq, duration)  → Sonar zumbador
    """

    # Puertos
    M1 = Port.M1
    M2 = Port.M2
    POWER = Port.POWER
    LED1 = Port.LED1
    LED2 = Port.LED2
    BUZZER = Port.BUZZER
    BUTTON = Port.BUTTON
    IF1 = Port.IF1
    IF2 = Port.IF2
    IF3 = Port.IF3
    IF4 = Port.IF4
    IF5 = Port.IF5
    IF6 = Port.IF6
    IF7 = Port.IF7
    IF8 = Port.IF8

    # Action codes
    _ACTION_GET_DEVICE_INFO = 0x01
    _ACTION_GET_INTERFACE_INFO = 0x02
    _ACTION_GET_ALL_INTERFACE_INFO = 0x03
    _ACTION_GET_MOTOR_INTERFACE_INFO = 0x04
    _ACTION_SET_LED = 0x10
    _ACTION_SET_MOTOR = 0x11
    _ACTION_SET_BUZZER = 0x13
    _ACTION_SET_MATRIX = 0x14
    _ACTION_LOW_BATTERY = 0x15
    _ACTION_CLICK_BUTTON = 0x16
    _ACTION_SET_WORK_MODE = 0x18
    _ACTION_SET_STEERING_ENGINE = 0x19
    _ACTION_SET_OUT_ENGINE = 0x1A
    _ACTION_SET_HARDWARE_UPDATE = 0x21
    _ACTION_GET_ULTRASONIC = 0xA1
    _ACTION_GET_BUTTON_INFO = 0xA2
    _ACTION_GET_VOLTAGE = 0xA3
    _ACTION_GET_TEMPERATURE_HUMIDITY = 0xA5
    _ACTION_GET_LIGHT_SENSOR = 0xA6
    _ACTION_GET_VOICE_SENSOR = 0xA7
    _ACTION_GET_INFRARED = 0xA8
    _ACTION_GET_GYRO = 0xA9
    _ACTION_GET_COLOR_SENSOR = 0xAA
    _ACTION_GET_TOUCH_BUTTON = 0xAB
    _ACTION_GET_ROCKER = 0xAE
    _ACTION_GET_FLAME_SENSOR = 0xAF
    _ACTION_GET_GAS_SENSOR = 0xB0
    _ACTION_GET_SPIRAL_POTENTIOMETER = 0xB1
    _ACTION_GET_LINE_POTENTIOMETER = 0xB2
    _ACTION_GET_EXT_IO_INPUT = 0xB4
    _ACTION_GET_EXT_APC = 0xB5
    _ACTION_GET_EXT_TEMP_HUMI = 0xB6

    def __init__(self, port: str = '/dev/ttyUSB0', baudrate: int = 115200):
        """
        Inicializar SDK.

        Args:
            port: Puerto serie (por defecto /dev/ttyUSB0)
            baudrate: Velocidad en baudios (por defecto 115200)
        """
        self._port = port
        self._baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._order = 0
        self._lock = threading.Lock()

    # =========================================================================
    # CONEXIÓN
    # =========================================================================

    def connect(self, timeout: float = 5.0) -> DeviceInfo:
        """
        Conectar al robot via UART.

        Args:
            timeout: Timeout máximo de conexión en segundos

        Returns:
            DeviceInfo con información del robot

        Raises:
            QScoutTimeout: Si el robot no responde
        """
        self._serial = serial.Serial(
            self._port, self._baudrate, timeout=0.01
        )
        time.sleep(0.5)
        self._drain(0.3)
        info = self.get_device_info()
        if info is None:
            self._serial.close()
            self._serial = None
            raise QScoutTimeout("No response from device")
        return info

    def disconnect(self):
        """Desconectar del robot."""
        if self._serial:
            self._serial.close()
            self._serial = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()

    # =========================================================================
    # INTERNOS - Protocolo
    # =========================================================================

    def _next_order(self) -> int:
        self._order = (self._order + 1) & 0xFF
        if self._order == 0:
            self._order = 1
        return self._order

    @staticmethod
    def _checksum(data: bytes) -> int:
        return sum(data) % 256

    def _build_packet(self, order: int, action: int, data: bytes = b'') -> bytes:
        """
        Construir paquete del protocolo Q-Scout.

        Formato: RB [SIZE] [ORDER] [ACTION] [DATA...] [CS]

        El SIZE incluye todos los bytes: RB(2) + SIZE(1) + ORDER(1) + ACTION(1) + DATA(n) + CS(1)
        """
        size = 6 + len(data)
        header = b'RB' + bytes([size, order, action])
        packet = header + data
        return packet + bytes([self._checksum(packet)])

    def _send_raw(self, packet: bytes):
        if not self._serial:
            raise QScoutError("Not connected")
        self._serial.write(packet)
        self._serial.flush()

    def _wait_response(self, timeout: float = 2.0) -> Optional[bytes]:
        if not self._serial:
            return None
        rb_buf = bytearray()
        start = time.time()
        while time.time() - start < timeout:
            b = self._serial.read(1)
            if not b:
                if rb_buf and len(rb_buf) >= 5 and rb_buf[0] == 0x52 and rb_buf[1] == 0x42:
                    cs = sum(rb_buf[:-1]) % 256
                    if cs == rb_buf[-1]:
                        return bytes(rb_buf)
                rb_buf = bytearray()
                continue
            byte_val = b[0]
            if byte_val == 0x52:
                rb_buf = bytearray(b)
            elif byte_val == 0x42 and len(rb_buf) == 1:
                rb_buf.append(byte_val)
            elif len(rb_buf) >= 2:
                rb_buf.append(byte_val)
                if len(rb_buf) >= 3:
                    expected = rb_buf[2]
                    if expected < 5 or expected > 30:
                        rb_buf = bytearray()
                    elif len(rb_buf) == expected:
                        cs = sum(rb_buf[:-1]) % 256
                        if cs == rb_buf[-1]:
                            return bytes(rb_buf)
                        rb_buf = bytearray()
        return None

    def _drain(self, duration: float = 0.3):
        if not self._serial:
            return
        end = time.time() + duration
        while time.time() < end:
            self._serial.read(500)

    def _send_and_wait(self, action: int, data: bytes = b'', timeout: float = 2.0) -> Optional[bytes]:
        with self._lock:
            order = self._next_order()
            packet = self._build_packet(order, action, data)
            self._drain(0.05)
            self._send_raw(packet)
            return self._wait_response(timeout)

    def _send_no_wait(self, action: int, data: bytes = b''):
        with self._lock:
            packet = self._build_packet(0, action, data)
            self._send_raw(packet)

    def send_raw(self, hex_str: str) -> Optional[bytes]:
        """
        Enviar paquete raw en formato hexadecimal.

        Args:
            hex_str: Paquete en hex (ej: "RB0911110032320000C2")

        Returns:
            Respuesta del robot o None
        """
        packet = bytes.fromhex(hex_str)
        self._send_raw(packet)
        return self._wait_response(2.0)

    def send_raw_packet(self, order: int, action: int, data: bytes = b'') -> Optional[bytes]:
        return self._send_and_wait(action, data)

    # =========================================================================
    # MOVIMIENTO - Control de motores
    # =========================================================================

    def set_move(self, m1_speed: int, m2_speed: int) -> bool:
        """
        Control directo de ambos motores.

        Paquete (9 bytes):
            RB [09] [ORDER] [0x11] [0x00] [M1_SPEED] [M2_SPEED] [CS]

        Diferencia con setMotor:
            - setMove usa SIZE=9 y controla AMBOS motores
            - setMotor usa SIZE=8 y controla UN motor

        Args:
            m1_speed: Velocidad motor izquierdo (-100 a 100)
            m2_speed: Velocidad motor derecho (-100 a 100)

        Returns:
            True si el robot respondió ACK
        """
        m1 = max(-100, min(100, m1_speed))
        m2 = max(-100, min(100, m2_speed))
        data = bytes([0x00, m1 & 0xFF, m2 & 0xFF])
        r = self._send_and_wait(self._ACTION_SET_MOTOR, data)
        return r is not None and len(r) >= 6 and r[4] == 1

    def set_motor(self, port: int, speed: int) -> bool:
        """
        Control individual de un motor.

        Paquete (8 bytes):
            RB [08] [ORDER] [0x11] [PORT] [SPEED] [CS]

        Diferencia con setMove:
            - setMotor usa SIZE=8 y controla UN motor
            - setMove usa SIZE=9 y controla AMBOS motores

        NOTA: Para movimiento diferencial del robot, usar set_move().
              Esta función es solo para control individual de un motor.

        Args:
            port: Puerto del motor (QScout.M1 o QScout.M2)
            speed: Velocidad (-100 a 100)

        Returns:
            True si el robot respondió ACK
        """
        speed = max(-100, min(100, speed))
        r = self._send_and_wait(self._ACTION_SET_MOTOR, bytes([port & 0xFF, speed & 0xFF]))
        return r is not None and len(r) >= 6 and r[4] == 1

    def stop(self) -> bool:
        """
        Parada total del robot.

        Usa set_move(0, 0) → paquete RB 09 order 0x11 0x00 0x00 0x00 CS

        IMPORTANTE: stop() NUNCA usa setMotor (8 bytes), porque
        enviar dos paquetes setMotor puede dejar un motor encendido
        si hay desfase temporal entre ambos paquetes.
        """
        return self.set_move(0, 0)

    def forward(self, speed: int = 50) -> bool:
        """
        Avanzar ambos motores a la misma velocidad.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(speed, speed)

    def backward(self, speed: int = 50) -> bool:
        """
        Retroceder ambos motores a la misma velocidad.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(-speed, -speed)

    def turn_left(self, speed: int = 50) -> bool:
        """
        Girar sobre la marcha (diferencial):
        M2 adelante, M1 atrás.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(-speed, speed)

    def turn_right(self, speed: int = 50) -> bool:
        """
        Girar sobre la marcha (diferencial):
        M1 adelante, M2 atrás.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(speed, -speed)

    def spin_left(self, speed: int = 50) -> bool:
        """
        Giro sobre su eje (pivot):
        M1 atrás, M2 adelante.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(-speed, speed)

    def spin_right(self, speed: int = 50) -> bool:
        """
        Giro sobre su eje (pivot):
        M1 adelante, M2 atrás.

        Args:
            speed: Velocidad (0 a 100, por defecto 50)
        """
        return self.set_move(speed, -speed)

    # =========================================================================
    # CONSULTAS - Información del dispositivo
    # =========================================================================

    def get_device_info(self) -> Optional[DeviceInfo]:
        """Obtener información del dispositivo."""
        r = self._send_and_wait(self._ACTION_GET_DEVICE_INFO)
        if r and len(r) >= 8:
            return DeviceInfo(r[4], r[5], r[6], r[7])
        return None

    def get_interface_info(self, port: int) -> Optional[InterfaceInfo]:
        """Obtener información de un puerto de interfaz."""
        r = self._send_and_wait(self._ACTION_GET_INTERFACE_INFO, bytes([port & 0xFF]))
        if r and len(r) >= 5:
            dt = r[4] if len(r) >= 6 else None
            return InterfaceInfo(port, dt)
        return None

    def get_all_interface_info(self) -> Optional[List[int]]:
        """Obtener información de todas las interfaces (no funciona en fw v3.0.1)."""
        r = self._send_and_wait(self._ACTION_GET_ALL_INTERFACE_INFO, timeout=5.0)
        if r and len(r) >= 15:
            return list(r[4:14])
        return None

    def get_motor_interface_info(self) -> Optional[dict]:
        """Obtener información de los motores."""
        r = self._send_and_wait(self._ACTION_GET_MOTOR_INTERFACE_INFO)
        if r and len(r) >= 7:
            return {'count': r[4], 'type': r[5]}
        return None

    def scan_ports(self) -> List[InterfaceInfo]:
        """Escanear puertos 1-8 y retornar dispositivos conectados."""
        results = []
        for port_val in range(1, 9):
            info = self.get_interface_info(port_val)
            if info:
                results.append(info)
        return results

    # =========================================================================
    # PERIFÉRICOS - LEDs, Buzzer, etc.
    # =========================================================================

    def set_led(self, port: int, r: int, g: int, b: int) -> bool:
        """
        Encender LED RGB.

        Args:
            port: LED1 o LED2
            r: Rojo (0-255)
            g: Verde (0-255)
            b: Azul (0-255)
        """
        r_val = max(0, min(255, r))
        g_val = max(0, min(255, g))
        b_val = max(0, min(255, b))
        resp = self._send_and_wait(self._ACTION_SET_LED, bytes([port & 0xFF, r_val, g_val, b_val]))
        return resp is not None and len(resp) >= 6

    def set_buzzer(self, port: int, frequency: int, duration_ms: int = 0) -> bool:
        """
        Sonar zumbador.

        NOTA: Este comando NO devuelve ACK (fire-and-forget).

        Args:
            port: Puerto del zumbador (QScout.BUZZER)
            frequency: Frecuencia en Hz (0-65535)
            duration_ms: Duración en ms (0-65535, 0=indefinido)
        """
        freq = max(0, min(65535, frequency))
        dur = max(0, min(65535, duration_ms))
        data = bytes([port & 0xFF]) + freq.to_bytes(2, 'big') + dur.to_bytes(2, 'big')
        self._send_no_wait(self._ACTION_SET_BUZZER, data)
        return True

    def set_matrix(self, port: int, data: bytes) -> bool:
        """Configurar matrix LED."""
        payload = bytes([port & 0xFF]) + data
        resp = self._send_and_wait(self._ACTION_SET_MATRIX, payload)
        return resp is not None and len(resp) >= 6

    def set_steering_engine(self, port: int, angle: int) -> bool:
        """Configurar servo."""
        angle = max(0, min(180, angle))
        resp = self._send_and_wait(self._ACTION_SET_STEERING_ENGINE, bytes([port & 0xFF, angle]))
        return resp is not None and len(resp) >= 6

    def set_out_engine(self, port: int, speed: int) -> bool:
        """Configurar motor externo."""
        speed = max(-100, min(100, speed))
        resp = self._send_and_wait(self._ACTION_SET_OUT_ENGINE, bytes([port & 0xFF, speed & 0xFF]))
        return resp is not None and len(resp) >= 6

    def set_work_mode(self, port: int, mode: int, value: int = 0) -> bool:
        """Configurar modo de trabajo."""
        resp = self._send_and_wait(self._ACTION_SET_WORK_MODE, bytes([port & 0xFF, mode, value]))
        return resp is not None

    def set_click_button(self, port: int, enable: bool) -> bool:
        """Habilitar/deshabilitar notificación de botón."""
        resp = self._send_and_wait(self._ACTION_CLICK_BUTTON, bytes([port & 0xFF, int(enable)]))
        return resp is not None and len(resp) >= 6 and resp[4] == 1

    def set_low_battery(self, port: int, enable: bool) -> bool:
        """Habilitar/deshabilitar notificación de batería baja."""
        resp = self._send_and_wait(self._ACTION_LOW_BATTERY, bytes([port & 0xFF, int(enable)]))
        return resp is not None and len(resp) >= 6 and resp[4] == 1

    # =========================================================================
    # SENSORES - Lectura de sensores (v1.1)
    # =========================================================================

    def get_ultrasonic(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_ULTRASONIC, bytes([port & 0xFF]))
        if r and len(r) >= 7:
            return (r[4] << 8) | r[5]
        return None

    def get_button(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_BUTTON_INFO, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_temperature_humidity(self, port: int) -> Optional[dict]:
        r = self._send_and_wait(self._ACTION_GET_TEMPERATURE_HUMIDITY, bytes([port & 0xFF]))
        if r and len(r) >= 7:
            return {'temperature': r[4], 'humidity': r[5]}
        return None

    def get_light(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_LIGHT_SENSOR, bytes([port & 0xFF]))
        if r and len(r) >= 7:
            return (r[4] << 8) | r[5]
        return None

    def get_voice(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_VOICE_SENSOR, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_infrared(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_INFRARED, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_gyro(self, port: int) -> Optional[bytes]:
        r = self._send_and_wait(self._ACTION_GET_GYRO, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4:-1]
        return None

    def get_color(self, port: int) -> Optional[dict]:
        r = self._send_and_wait(self._ACTION_GET_COLOR_SENSOR, bytes([port & 0xFF]))
        if r and len(r) >= 8:
            return {'r': r[4], 'g': r[5], 'b': r[6]}
        return None

    def get_touch_button(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_TOUCH_BUTTON, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_rocker(self, port: int) -> Optional[dict]:
        r = self._send_and_wait(self._ACTION_GET_ROCKER, bytes([port & 0xFF]))
        if r and len(r) >= 8:
            return {'x': r[4], 'y': r[5], 'button': r[6]}
        return None

    def get_flame(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_FLAME_SENSOR, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_gas(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_GAS_SENSOR, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[4]
        return None

    def get_spiral_potentiometer(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_SPIRAL_POTENTIOMETER, bytes([port & 0xFF]))
        if r and len(r) >= 7:
            return (r[4] << 8) | r[5]
        return None

    def get_line_potentiometer(self, port: int) -> Optional[int]:
        r = self._send_and_wait(self._ACTION_GET_LINE_POTENTIOMETER, bytes([port & 0xFF]))
        if r and len(r) >= 7:
            return (r[4] << 8) | r[5]
        return None

    def get_voltage(self, port: int) -> Optional[int]:
        """Leer voltaje (NO funciona en fw v3.0.1)."""
        r = self._send_and_wait(self._ACTION_GET_VOLTAGE, bytes([port & 0xFF]))
        if r and len(r) >= 6:
            return r[5]
        return None