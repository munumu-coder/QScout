# Q-Scout Python SDK v1.0

SDK para controlar el robot Robobloq Q-Scout via UART desde Linux.

## Requisitos

- Python 3.7+
- Robot Robobloq Q-Scout conectado via USB
- Puerto serie disponible (normalmente `/dev/ttyUSB0`)

## Instalación

```bash
pip install pyserial
```

## Permisos de puerto serie

El usuario debe estar en el grupo `dialout` para acceder al puerto serie:

```bash
sudo usermod -a -G dialout $USER
```

Después cerrar sesión y volver a entrar (o reiniciar).

## Conexión USB

1. Conectar el Q-Scout al PC via cable USB
2. Verificar el puerto:
   ```bash
   ls /dev/ttyUSB*
   ```
3. Ejecutar el script de validación:
   ```bash
   python3 sdk_validation.py
   ```

## Uso básico

```python
import time
from qscout import QScout

# Conectar al robot
with QScout() as robot:
    # Avanzar 2 segundos
    robot.forward(50)
    time.sleep(2)
    
    # Parar
    robot.stop()
```

## API de movimiento

| Método | Descripción |
|--------|-------------|
| `forward(speed)` | Avanzar ambos motores |
| `backward(speed)` | Retroceder ambos motores |
| `turn_left(speed)` | Girar izquierda (diferencial) |
| `turn_right(speed)` | Girar derecha (diferencial) |
| `spin_left(speed)` | Giro sobre su eje izquierda |
| `spin_right(speed)` | Giro sobre su eje derecha |
| `stop()` | Parada total |

Velocidad: 0-100 (por defecto 50)

## API de bajo nivel

```python
# Control directo de ambos motores
robot.set_move(m1_speed, m2_speed)

# Control individual de un motor
robot.set_motor(QScout.M1, speed)

# Enviar paquete raw
robot.send_raw("RB0911110032320000C2")
```

## Periféricos

```python
# LED RGB
robot.set_led(QScout.LED1, r=255, g=0, b=0)

# Zumbador (sin ACK)
robot.set_buzzer(QScout.BUZZER, frequency=1000, duration_ms=500)
```

## Protocolo

El protocolo UART usa paquetes con formato:

```
RB [SIZE] [ORDER] [ACTION] [DATA...] [CS]
```

- **SIZE**: Tamaño total del paquete
- **ORDER**: Número de secuencia
- **ACTION**: Código de acción
- **DATA**: Datos (opcional)
- **CS**: Checksum (suma de todos los bytes % 256)

### Motores - Dos formatos

| Formato | Tamaño | Descripción |
|---------|--------|-------------|
| `setMove` | 9 bytes | Controla AMBOS motores |
| `setMotor` | 8 bytes | Controla UN motor |

`stop()` usa exclusivamente `setMove(0,0)` para evitar problemas de sincronización.

## Archivos

- `qscout.py` - SDK principal
- `sdk_validation.py` - Test de validación completa
- `movimiento_ejemplo.py` - Ejemplos de movimiento
- `PROTOCOL.md` - Documentación completa del protocolo

## Licencia

Uso interno - Proyecto de investigación