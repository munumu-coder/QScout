#!/usr/bin/env python3
"""
Test de diagnóstico de canales del motor Q-Scout.
Usa exclusivamente Protocol.setMove (paquete RB 09).
Registra paquetes HEX, ACK y mensajes debug del ESP32.
"""

import sys
import time
from datetime import datetime

sys.path.insert(0, '/media/munumu/42529c62-b253-4db5-b8d3-bea4b7cf5e37/Documents/Default Project')
from qscout import QScout


def ts():
    return datetime.now().strftime('%H:%M:%S.%f')[:-3]


def log(msg):
    print(f"[{ts()}] {msg}")


def build_set_move(order, m1_speed, m2_speed):
    size = 9
    header = b'RB' + bytes([size, order, 0x11])
    packet = header + bytes([0x00, m1_speed & 0xFF, m2_speed & 0xFF])
    checksum = sum(packet) % 256
    return packet + bytes([checksum])


def send_and_log(robot, label, packet):
    log(f"  TX: {packet.hex()}")
    robot._drain(0.05)
    robot._send_raw(packet)
    r = robot._wait_response(timeout=2.0)
    if r:
        log(f"  RX: {r.hex()} | ACK result={r[4]}")
        return r[4] == 1
    else:
        log(f"  RX: TIMEOUT")
        return False


def drain_debug(robot, duration=1.0):
    """Lee mensajes debug del ESP32 (texto motorForward/motorReverse)."""
    end = time.time() + duration
    text = b''
    while time.time() < end:
        chunk = robot._serial.read(200)
        if chunk:
            text += chunk
    if text:
        decoded = text.decode('ascii', errors='replace').strip()
        for line in decoded.split('\n'):
            line = line.strip()
            if line:
                log(f"  ESP32: {line}")
    return text


def test_phase(robot, label, m1, m2, hold_sec=3, wait_sec=2):
    log(f"\n{'='*60}")
    log(f"FASE: {label}")
    log(f"  setMove(M1={m1}, M2={m2})")
    log(f"{'='*60}")

    order = robot._next_order()
    pkt = build_set_move(order, m1, m2)
    send_and_log(robot, label, pkt)

    log(f"  Manteniendo {hold_sec}s...")
    time.sleep(hold_sec)

    log(f"  → STOP")
    order = robot._next_order()
    pkt = build_set_move(order, 0, 0)
    send_and_log(robot, "stop", pkt)

    log(f"  Esperando {wait_sec}s + leyendo debug...")
    drain_debug(robot, wait_sec + 0.5)


def main():
    log("=" * 60)
    log("DIAGNÓSTICO DE CANALES DE MOTOR Q-SCOUT")
    log("Protocolo: setMove (RB 09, action 0x11)")
    log("=" * 60)

    robot = QScout()

    try:
        info = robot.connect()
        log(f"Conectado: Firmware v{info.firmware}, HW {info.hw_version}")
    except Exception as e:
        log(f"[ERROR] No se pudo conectar: {e}")
        return

    try:
        log("\n--- STOP INICIAL ---")
        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        send_and_log(robot, "stop inicial", pkt)
        drain_debug(robot, 2.0)

        test_phase(robot, "M1 ADELANTE speed=40", 40, 0)
        test_phase(robot, "M2 ADELANTE speed=40", 0, 40)
        test_phase(robot, "M1 ATRÁS speed=-40", -40, 0)
        test_phase(robot, "M2 ATRÁS speed=-40", 0, -40)

    except KeyboardInterrupt:
        log("\n[INTERRUPCION] Enviando stop...")
        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        robot._send_raw(pkt)
    except Exception as e:
        log(f"\n[ERROR] {e}")
        order = robot._next_order()
        pkt = build_set_move(order, 0, 0)
        robot._send_raw(pkt)
    finally:
        robot.disconnect()

    log("\n" + "=" * 60)
    log("DIAGNÓSTICO COMPLETADO")
    log("=" * 60)


if __name__ == '__main__':
    main()
