#!/usr/bin/env python3
"""
Diagnóstico de batería del Q-Scout.
Intenta get_voltage con todos los puertos conocidos.
No envía comandos de movimiento.
"""

import sys
import time
import struct

sys.path.insert(0, '/media/munumu/42529c62-b253-4db5-b8d3-bea4b7cf5e37/Documents/Default Project')
from qscout import QScout


def build_voltage_packet(order, port):
    """Construye paquete get_voltage exactamente como Protocol.getVoltage."""
    size = 7
    header = b'RB' + bytes([size, order, 0xA3])
    packet = header + bytes([port & 0xFF])
    checksum = sum(packet) % 256
    return packet + bytes([checksum])


def try_voltage(robot, port, name):
    """Envía get_voltage y captura respuesta con debug completo."""
    order = robot._next_order()
    pkt = build_voltage_packet(order, port)

    print(f"\n  Puerto: {name} (0x{port & 0xFF:02X})")
    print(f"  Paquete: {pkt.hex()}")

    robot._drain(0.1)
    robot._send_raw(pkt)
    r = robot._wait_response(timeout=3.0)

    if r:
        print(f"  Respuesta: {r.hex()}")
        print(f"  Tamaño: {r[2]} bytes")
        print(f"  Order: {r[3]}")
        if len(r) >= 6:
            voltage_raw = r[4]
            print(f"  Dato bruto (byte[4]): {voltage_raw}")
            print(f"  Dato bruto (byte[5]): {r[5] if len(r) > 5 else 'N/A'}")
        return r
    else:
        print(f"  Respuesta: NINGUNA")
        return None


def main():
    print("=" * 60)
    print("  DIAGNOSTICO DE BATERIA Q-SCOUT")
    print("=" * 60)

    robot = QScout()

    try:
        info = robot.connect()
        print(f"\nConectado: Firmware v{info.firmware}, HW {info.hw_version}")
    except Exception as e:
        print(f"\n[ERROR] No se pudo conectar: {e}")
        return

    # Confirmar vivo
    print("\n--- Verificando conexion ---")
    alive = robot.get_device_info()
    if alive:
        print(f"  Device alive: v{alive.firmware}")
    else:
        print("  [ERROR] Device not responding")
        robot.disconnect()
        return

    # === ANALISIS DEL CODIGO FUENTE ===
    print("\n" + "=" * 60)
    print("  1. ANALISIS DEL CODIGO FUENTE")
    print("=" * 60)

    print("""
  COMANDO: get_voltage (0xA3)
  - Paquete: RB + size(7) + order + 0xA3 + port(1B) + checksum
  - Puerto usado por MyQode: board_power = -3 (0xFD)
  - Funcion parseVoltage: lee byte[5] como UInt8
  - Respuesta esperada: RB + size(6) + order + ??? + checksum

  ESTADO EN MyQode:
  - setLowBatteryBack(board_power, 1) → COMENTADO en source
  - getVoltage() existe en RobotItem pero NO se llama desde bloques
  - low_battery action (0x15) → habilita notificacion, NO lee voltaje

  FIRWARE (QmindX.py):
  - NO contiene funcion get_voltage
  - NO maneja action 0xA3
  - La etapa de potencia esta en firmware compilado (no MicroPython)
    """)

    # === PRUEBAS GET_VOLTAGE ===
    print("=" * 60)
    print("  2. PRUEBAS GET_VOLTAGE")
    print("=" * 60)

    ports_to_test = [
        (-3, 0xFD, "board_power"),
        (-1, 0xFF, "board_motor_m1"),
        (-2, 0xFE, "board_motor_m2"),
        (1, 0x01, "interface1"),
        (2, 0x02, "interface2"),
    ]

    results = {}
    for port_val, port_byte, name in ports_to_test:
        r = try_voltage(robot, port_byte, name)
        results[name] = r

    # === INTENTAR CON setLowBattery HABILITADO ===
    print("\n" + "=" * 60)
    print("  3. HABILITAR low_battery NOTIFICATION + REINTENTAR")
    print("=" * 60)

    print("\n  Enviando setLowBatteryBack(board_power, 1)...")
    robot.set_low_battery(QScout.POWER, True)
    time.sleep(0.5)
    robot._drain(0.5)

    print("  Reintentando get_voltage(board_power)...")
    r = try_voltage(robot, 0xFD, "board_power (post-notification)")

    # === INTENTAR CON setClickButton HABILITADO ===
    print("\n  Enviando setClickButton(board_button, 1)...")
    robot.set_click_button(QScout.BUTTON, True)
    time.sleep(0.5)
    robot._drain(0.5)

    print("  Reintentando get_voltage(board_power)...")
    r = try_voltage(robot, 0xFD, "board_power (post-clickButton)")

    # === RESUMEN ===
    print("\n" + "=" * 60)
    print("  4. RESUMEN")
    print("=" * 60)

    any_response = any(v is not None for v in results.values())

    if any_response:
        print("\n  [OK] El firmware SI responde a get_voltage")
    else:
        print("\n  [CONCLUSION] El firmware v3.0.1 NO responde a get_voltage")
        print("  Ningun puerto produce respuesta al comando 0xA3.")
        print("  Esto confirma que la lectura de batería por UART")
        print("  NO está implementada en esta versión de firmware.")

    print("""
  HALLAZGOS:
  1. get_voltage (0xA3) → SIN RESPUESTA en todos los puertos
  2. setLowBattery (0x15) → ACK OK, pero es notificacion, no lectura
  3. parseVoltage lee byte[5] pero NUNCA llega respuesta
  4. MyQode tiene el codigo pero NO lo usa (comentado)
  5. QmindX.py NO contiene handler para 0xA3
  6. El voltaje de batería NO se puede leer por UART

  IMPLICACIONES PARA MOTORES:
  - La etapa de potencia puede funcionar sin lectura de voltaje
  - La batería alimenta motores independientemente del UART
  - El problema de motores NO es falta de comando de voltaje
  - El problema puede ser: batería descargada, conexión, o driver
    """)

    robot.disconnect()


if __name__ == '__main__':
    main()
