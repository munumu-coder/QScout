#!/usr/bin/env python3
"""
SDK Validation Test v1.0
========================

Test completo de validación del SDK qscout.py.

Comprueba:
    A) Conexión UART
    B) get_device_info()
    C) LED
    D) Buzzer
    E) Movimiento (forward, backward, spin_left, spin_right, stop)

Uso:
    python3 sdk_validation.py
"""

import sys
import time
from datetime import datetime
from qscout import QScout, QScoutTimeout


class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.ack_received = False
        self.message = ""
        self.timestamp = None

    def success(self, ack: bool = False, msg: str = ""):
        self.passed = True
        self.ack_received = ack
        self.message = msg
        self.timestamp = datetime.now()

    def fail(self, msg: str):
        self.passed = False
        self.message = msg
        self.timestamp = datetime.now()


def print_header(title: str):
    print(f"\n{'='*60}")
    print(f" {title}")
    print(f"{'='*60}")


def print_result(result: TestResult):
    status = "✓ PASS" if result.passed else "✗ FAIL"
    ack = " [ACK]" if result.ack_received else ""
    print(f"  {status}{ack} {result.name}")
    if result.message:
        print(f"         {result.message}")


def test_connection(robot: QScout) -> TestResult:
    """A) Probar conexión UART."""
    result = TestResult("Conexión UART")
    try:
        info = robot.get_device_info()
        if info:
            result.success(True, f"Firmware v{info.firmware}, HW v{info.hw_version}")
        else:
            result.fail("No response from device")
    except Exception as e:
        result.fail(str(e))
    return result


def test_device_info(robot: QScout) -> TestResult:
    """B) Probar get_device_info()."""
    result = TestResult("get_device_info()")
    try:
        info = robot.get_device_info()
        if info:
            result.success(True, f"FW={info.firmware}, HW={info.hw_version}")
        else:
            result.fail("No response")
    except Exception as e:
        result.fail(str(e))
    return result


def test_led(robot: QScout) -> TestResult:
    """C) Probar LED."""
    result = TestResult("LED (rojo)")
    try:
        resp = robot._send_and_wait(
            robot._ACTION_SET_LED,
            bytes([robot.LED1 & 0xFF, 255, 0, 0])
        )
        if resp and len(resp) >= 6:
            result.success(True, "LED1 encendido (rojo)")
        else:
            result.fail("No ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_led_off(robot: QScout) -> TestResult:
    """C) Apagar LED."""
    result = TestResult("LED (apagar)")
    try:
        resp = robot._send_and_wait(
            robot._ACTION_SET_LED,
            bytes([robot.LED1 & 0xFF, 0, 0, 0])
        )
        if resp and len(resp) >= 6:
            result.success(True, "LED1 apagado")
        else:
            result.fail("No ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_buzzer(robot: QScout) -> TestResult:
    """D) Probar buzzer."""
    result = TestResult("Buzzer (1000Hz, 200ms)")
    try:
        robot.set_buzzer(robot.BUZZER, 1000, 200)
        result.success(False, "Enviado (fire-and-forget, sin ACK)")
    except Exception as e:
        result.fail(str(e))
    return result


def test_forward(robot: QScout) -> TestResult:
    """E) Probar forward()."""
    result = TestResult("forward(30)")
    try:
        ack = robot.forward(30)
        result.success(ack, "Motores adelante" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_stop_after_forward(robot: QScout) -> TestResult:
    """E) Probar stop() después de forward."""
    result = TestResult("stop() [post-forward]")
    try:
        ack = robot.stop()
        result.success(ack, "Motores parados" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_backward(robot: QScout) -> TestResult:
    """E) Probar backward()."""
    result = TestResult("backward(30)")
    try:
        ack = robot.backward(30)
        result.success(ack, "Motores atrás" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_stop_after_backward(robot: QScout) -> TestResult:
    """E) Probar stop() después de backward."""
    result = TestResult("stop() [post-backward]")
    try:
        ack = robot.stop()
        result.success(ack, "Motores parados" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_spin_left(robot: QScout) -> TestResult:
    """E) Probar spin_left()."""
    result = TestResult("spin_left(30)")
    try:
        ack = robot.spin_left(30)
        result.success(ack, "Giro izquierda" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_stop_after_spin_left(robot: QScout) -> TestResult:
    """E) Probar stop() después de spin_left."""
    result = TestResult("stop() [post-spin_left]")
    try:
        ack = robot.stop()
        result.success(ack, "Motores parados" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_spin_right(robot: QScout) -> TestResult:
    """E) Probar spin_right()."""
    result = TestResult("spin_right(30)")
    try:
        ack = robot.spin_right(30)
        result.success(ack, "Giro derecha" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def test_stop_after_spin_right(robot: QScout) -> TestResult:
    """E) Probar stop() después de spin_right."""
    result = TestResult("stop() [post-spin_right]")
    try:
        ack = robot.stop()
        result.success(ack, "Motores parados" if ack else "Sin ACK")
    except Exception as e:
        result.fail(str(e))
    return result


def main():
    print_header("Q-Scout SDK Validation Test v1.0")
    print(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Python: {sys.version.split()[0]}")

    results = []

    # Conectar
    print("\n  Conectando al robot...")
    try:
        robot = QScout()
        info = robot.connect()
        print(f"  ✓ Conectado: Q-Scout v{info.firmware}")
    except QScoutTimeout:
        print("  ✗ No se pudo conectar (timeout)")
        sys.exit(1)
    except Exception as e:
        print(f"  ✗ Error: {e}")
        sys.exit(1)

    try:
        # A) Conexión
        print_header("A) Conexión")
        results.append(test_connection(robot))
        results.append(test_device_info(robot))

        # B) LED
        print_header("B) LED")
        results.append(test_led(robot))
        time.sleep(0.5)
        results.append(test_led_off(robot))

        # C) Buzzer
        print_header("C) Buzzer")
        results.append(test_buzzer(robot))
        time.sleep(0.5)

        # D) Movimiento
        print_header("D) Movimiento")
        print("  Ejecutando movimientos...")

        results.append(test_forward(robot))
        time.sleep(1.5)
        results.append(test_stop_after_forward(robot))
        time.sleep(0.5)

        results.append(test_backward(robot))
        time.sleep(1.5)
        results.append(test_stop_after_backward(robot))
        time.sleep(0.5)

        results.append(test_spin_left(robot))
        time.sleep(1.5)
        results.append(test_stop_after_spin_left(robot))
        time.sleep(0.5)

        results.append(test_spin_right(robot))
        time.sleep(1.5)
        results.append(test_stop_after_spin_right(robot))

    finally:
        robot.stop()
        robot.disconnect()

    # Resumen
    print_header("RESUMEN")
    passed = sum(1 for r in results if r.passed)
    total = len(results)

    for r in results:
        print_result(r)

    print(f"\n  Total: {passed}/{total} tests pasados")

    if passed == total:
        print("  ✓ SDK VALIDADO CORRECTAMENTE")
        return 0
    else:
        print("  ✗ ALGUNOS TESTS FALLARON")
        return 1


if __name__ == "__main__":
    sys.exit(main())